<?php
class hrModel extends CI_Model {

public function __construct(){
$this->load->database('default');
$this->load->library('session');
    date_default_timezone_set("Asia/Kolkata"); 
		$data = $this->db->select('job_id')->from('jobs')->where('deleted','no')->where('expires <=',date('Y-m-d'))->get()->result();
		if($data)
		{	$expired = array();
			foreach($data as $d) array_push($expired,array('job_id'=>$d->job_id,'deleted'=>'yes'));
			$this->db->update_batch('jobs',$expired,'job_id');
		}
    }
    public function getProfile(){
        $query = $this->db->get('hr');
        return $query->result();
    }
    public function getskills(){
        $query = $this->db->get('skills');
        return $query->result();
    }
    public function updateHr($data, $hrid){
        return $this->db->update('hr',$data, ['hrid'=>$hrid]);
    }
    public function postJob($data) {
        $this->db->insert('jobs',$data);
        return $this->db->insert_id();
    }
    public function updateJob($data,$job_id) {
        return $this->db->update('jobs',$data, ['job_id'=>$job_id]);
        // $this->db->where('job_id',$job_id);
        // return $this->db->update('jobs',$data);
    }
    public function validate_author($job_id){
		$where = array('deleted'=>'no','job_id'=>$job_id,'created_by'=>$this->session->set_userdata('user')->hrid);
		return $this->db->from('jobs')->where('deleted','no')->where($where)->get()->num_rows();
	}
    // public function getjobs(){
    //     $query = $this->db->get('jobs');
    //     return $query->result();
    // }
    public function delete_job($job_id) {
        return $this->db->delete("jobs", ['job_id'=>$job_id]);
	}
    public function get_job($job_id) {
		return $this->db->select('jobs.*,hr.name')->from('jobs')->join('hr','hrid=jobs.created_by')->where('jobs.job_id',$job_id)->where('jobs.deleted','no')->get()->row();
	}
    public function editjob($job_id){
        $query = $this->db->get_where('jobs',['job_id'=>$job_id]);
        return $query->row();
    }
}