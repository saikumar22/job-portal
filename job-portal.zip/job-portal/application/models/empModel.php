<?php
class empModel extends CI_Model {
    public function __construct(){
    $this->load->database('default');
    $this->load->library('session');
    }
    public function getProfile(){
        $query = $this->db->get('employee');
        return $query->result();
    }
    public function updateEmp($data, $id){
        return $this->db->update('employee',$data, ['id'=>$id]);
    }
    
    public function get_job($job_id) {
		return $this->db->select('jobs.*,hr.name')->from('jobs')->join('hr','hrid=jobs.created_by')->where('jobs.job_id',$job_id)->where('jobs.deleted','no')->get()->row();
	}
    
    public function applied($aid){  
        $insert = $this->db->insert('applied', $aid);
        if ($insert) {
            return $this->db->insert_aid();
        } else {
            return false;
        }
    }
}