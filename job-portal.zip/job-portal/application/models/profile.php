<?php
use codeginater\Model;

class products extends CI_Model {
     protected $table = 'hr';
     protected $primarykey = 'hrid';

     protected $allowedFields=[
         'name',
         'email',
         'password',
         'companyname',
         'companytype',
         'pincode',
         'companyaddress',
         'mobile'
     ];
}
?>