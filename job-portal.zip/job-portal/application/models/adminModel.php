<?php
class adminModel extends CI_Model {
    public function __construct(){
    $this->load->database('default');
    $this->load->library('session');
    }

public function adminLogin($data){
    $query = $this->db->get_where('admin', $data);
    if($query){   
    return $query->row();
    }
    return false;
}
public function getpaid(){
    $query = $this->db->get('paid');
    return $query->result();
}
public function get_job($job_id) {
    return $this->db->select('jobs.*,hr.name')->from('jobs')->join('hr','hrid=jobs.created_by')->where('jobs.job_id',$job_id)->where('jobs.deleted','no')->get()->row();
}

//insert product
public function insertpost($data){
    return $this->db->insert('paid',$data);
}
//edit and update product
public function editPost($id){
    $query = $this->db->get_where('paid',['postid'=>$id]);
    return $query->row();
}
public function updatePost($data, $id){
    return $this->db->update('paid',$data, ['postid'=>$id]);
}

// delete product
public function checkPostImage($id){
    $query= $this->db->get_where('paid',['postid'=>$id]);
    return $query->row();
}
public function deletePost($id){
    return $this->db->delete('paid', ['postid'=>$id]);
}
}