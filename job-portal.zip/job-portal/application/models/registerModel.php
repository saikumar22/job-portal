<?php
class registerModel extends CI_Model {
public function __construct(){
$this->load->database('default');
$this->load->library('session');
}
public function insert_empregister($data) {
    $insert = $this->db->insert('employee', $data);
    if ($insert) {
    return $this->db->insert_id();
    } else {
    return false;
    }
}
public function insert_hrRegister($data) {
    $insert = $this->db->insert('hr', $data);
    if ($insert) {
    return $this->db->insert_id();
    } else {
    return false;
    }

}
public function empLogin($data){
    $query = $this->db->get_where('employee', $data);
    if($query){   
    return $query->row();
    }
    return false;
}

public function hrLogin($data){
    $query = $this->db->get_where('hr', $data);
    if($query){   
    return $query->row();
    }
    return false;
}

public function verify_login($where){
    return $this->db->select('hrid,email,name')->from('hr')->where($where)->get()->row();
}

public function follow($fid){  
    $insert = $this->db->insert('follow', $fid);
    if ($insert) {
        return $this->db->insert_fid();
    } else {
        return false;
    }
}

public function jobs(){
    $this->db->order_by("date_created", "desc");
    $query = $this->db->get($this->jobs);
    return $query->result();
}

public function search($key){
    $this->db->like('title',$key);
    $query = $this->db->get('jobs');
    return $query->result();
}
// public function searchcompany($key){
//     $this->db->like('company',$key);
//     $query = $this->db->get('jobs');
//     return $query->result();
// }
public function getpaid(){
    $query = $this->db->get('paid');
    return $query->result();
}
public function insert_feedback($data) {
    $insert = $this->db->insert('feedback', $data);
    if ($insert) {
    return $this->db->insert_id();
    } else {
    return false;
    }
}
public function logoutUser($status, $date){
		if(isset($_SESSION['hr_id'])){
			$currentSession = $_SESSION['hr_id'];
			$this->db->query("UPDATE hr SET hr_status = '$status' , last_logout = '$date' WHERE 
			hrid = '$currentSession'");
		}
	}
}