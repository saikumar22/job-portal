<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
    .btn-primary {
        margin-top: 5px;
    }

    #myNavbar li {
        font-size: 15px;
    }

    #jobsview h4 {
        margin-top: 50px;
    }

    .hrnav {
        font: 12pt Georgia, "Times New Roman", Times, serif;
        line-height: 1.3;
    }
    </style>
    <title>JOB-PORTAL</title>
</head>

<body>