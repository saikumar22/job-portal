<nav class="navbar navbar-default navbar-fixed-top" id="indexnav">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href=""><img src="<?=base_url('/assets/images/job.png')?>" alt="img"
                        style="width: 100px; margin-top: -15px;"></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="<?=base_url();?>homeController/index">HOME</a></li>
                <li><a href="<?=base_url();?>empController/companies">COMPANIES</a></li>
                <li><a href="<?=base_url();?>homeController/recruiters">RECRUITERS</a></li>
                <li><a href="<?=base_url();?>homeController/services">SERVICES</a></li>
                <li>
                    <?php if(isset($this->session->id)){?>
                <li>
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">MY PROFILE
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <li> 
                        <a class="dropdown-item" href="<?=base_url();?>empController/profile">PROFILE</a>
                        </li>                        
                        <li>
                        <a class="dropdown-item" href="<?=base_url();?>empController/appliedview">APPLIED</a>
                        </li>
                        <li>
                        <a class="dropdown-item" href="<?= base_url();?>homeController/logout">LOGOUT</a>
                        </li>
                    </ul>
                </li>
                <?php } 
                    else{?>
                <li>
                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">LOGIN
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?= base_url();?>homeController/hrlogin">HR login</a>
                        <li><a class="dropdown-item" href="<?= base_url();?>homeController/emplogin">Employee login</a></li>
                        
                    </ul>
                </li>
                <?php } ?>
                </li>
            </ul>
        </div>
    </div>
</nav>