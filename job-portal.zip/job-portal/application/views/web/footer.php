<style>
.navbar-brand {
    width: 100px;
}

footer {
    color: #666666;
    font: 14px Roboto sans-serif;
    /* background-color: #2e3339; */
    background: #2b5876;
    background: -webkit-linear-gradient(to right, #4e4376, #2b5876);
    background: linear-gradient(to right, #4e4376, #2b5876);
    padding: 10px;
}

li {
    list-style: none;
    /* color: b6b8ba; */
    padding: 5px;
    font: 12px Roboto sans-serif;
}

.fa-facebook {
    background: #3B5998;
    width: 25px;
    height: 25px;
    padding: 10px;
    color: white;
}

.fa-twitter {
    background: #55ACEE;
    width: 25px;
    height: 25px;
    padding: 10px;
    color: white;
}

.fa-linkedin {
    background: #007bb5;
    width: 25px;
    height: 25px;
    padding: 10px;
    color: white;
}

.list li {
    color: #c2bdbd;
    font: 15px Roboto sans-serif;
}

.listyle {
    font: 20px Roboto sans-serif;
    color: white;
}
</style>
<!-- <script src="\assets\bootstrap-3.4.1-dist\js\bootstrap.min.js"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
<footer>
    <div class="container" style="width:100%">
        <div class="row">
            <div class="col-sm-3">
                <ul>
                    <li class="listyle">Information</li>
                </ul>
                <ul class="list">
                    <li>About Us</li>
                    <li>Terms & conditions</li>
                    <li>Contact us</li>
                    <li>FAQs</li>
                    <li>Trust and Safety</li>
                </ul>
            </div>

            <div class="col-sm-3">
                <ul>
                    <li class="listyle">Job Seeker</li>
                </ul>
                <ul class="list">
                    <li>Register now</li>
                    <li>Search jobs</li>
                    <li>Login</li>
                    <li>Create job Alert</li>
                    <li>Mobile site</li>
                </ul>
            </div>

            <div class="col-sm-3">
                <ul>
                    <li class="listyle">Job Seeker Services</li>
                </ul>
                <ul class="list">
                    <li>Prioirty applicants</li>
                    <li>Resume Display</li>
                    <li>Recruiter connection</li>
                    <li>Jobs4U</li>
                </ul>
            </div>

            <div class="col-sm-3">
                <ul>
                    <li class="listyle">Employers</li>
                </ul>
                <ul class="list">
                    <li>Job posting</li>
                    <li>Resume Database Access</li>
                    <li>Buy Resume Packages Online</li>
                    <li>Recruiter Login</li>
                    <li>Transition Services</li>
                    <li>Report a problem</li>
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-linkedin"></a>
                </ul>
            </div>
        </div>
    </div>
</footer>

</html>