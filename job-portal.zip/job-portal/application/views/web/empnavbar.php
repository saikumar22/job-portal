<!-- 
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href=""><img src="./assets/images/job.png" alt="img"
                        style="width: 100%; height: 55px; margin-top: -15px;;"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?=base_url();?>homeController/jobs">JOBS</a></li>
                    <li><a href="#">COMPANIES</a></li>
                    <li><a href="<?=base_url();?>homeController/recruiters">RECRUITERS</a></li>
                    <li><a href="<?=base_url();?>homeController/services">SERVICES</a></li>
                    <li><a href="#contact">CONTACT US</a></li>
                    <li><a href="<?=base_url();?>homeController/logout">LOGOUT</a></li>
                </ul>
            </div>
        </div>
    </nav> -->