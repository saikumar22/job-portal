<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="hrnav">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- <a class="navbar-brand" href=""><img src="..\assets\images\job.png" alt="img"
                        style="width: 20%;  margin-top: -15px;;"></a> -->
                <a class="navbar-brand" href=""><img src="<?=base_url('/assets/images/job.png')?>" alt="img"
                        style="width: 20%;  margin-top: -15px;"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?=base_url();?>adminController/post">HOME</a></li>
                    <li><a href="<?=base_url();?>adminController/jobs">JOBS</a></li>
                    <li><a href="<?=base_url();?>adminController/hr">HR</a></li>
                    <li><a href="<?=base_url();?>adminController/employee">EMPLOYEE</a></li>
                    <li><a href="<?=base_url();?>adminController/paidreview">REVIEW</a></li>
                    <li><a href="<?=base_url();?>adminController/feedback">FEEDBACK</a></li>
                    <li><a href="<?=base_url();?>homeController/logout">LOGOUT</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>