<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <title>Sign Up</title>
    <style>
    body {
        background: linear-gradient(90deg, #C7C5F4, #776BCC);
    }

    h5 {
        margin-top: 100px;
        text-align: center;
        color: black;
    }

    .card {
        padding: 20px;
        margin-top: 20px;
        background-color: white;
    }

    .col-sm-6 {
        padding: 10px;
    }

    h5 {
        font-size: 20px;
    }

    .header {
        text-align: center;
        margin-top: 0px;
    }

    .btn {
        margin-left: 200px;
        margin-top: 0px;
    }

    .imgdisplay {
        width: 70%;
        height: 160px;
        margin-top: 100px;
        border-radius: 100%;
        border: 3px solid black;
    }

    .upload {
        margin: -50px 45px 0px 60px;
        color: blue;
    }

    .profile {
        margin: -50px 0px 0px 60px;
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <h5>Edit Profile Details</h5>
            <?php foreach ($hr as $hr) {  ?>
            <div class="col-sm-3 col-lg-3 col-md-3 profile">
                <a href="" class="message" data-toggle="modal" data-target="#image">
                    <img src="<?=base_url('images/'.$hr->img)?>" class="imgdisplay" alt="Image">
                    <div class="upload" id="upload">
                        Upload
                    </div>
            </div>
            </a>
            <div class="col-sm-6">
                <div class="card">
                    <form action="<?= base_url('hrController/update/'.$hr->hrid)?>" method="POST"
                        enctype="multipart/form-data">

                        <div class="row">
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput1" class="form-label">Name:</label>
                                <input type="text" class="form-control" name="name" value="<?= $hr->name;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput4" class="form-label">Role:</label>
                                <input type="text" class="form-control" name="role" value="<?= $hr->role;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput4" class="form-label">Mobile:</label>
                                <input type="text" class="form-control" name="mobile" value="<?= $hr->mobile;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput4" class="form-label">Company Name:</label>
                                <input type="text" class="form-control" name="companyname"
                                    value="<?= $hr->companyname;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput2" class="form-label">Email:</label>
                                <input type="email" class="form-control" name="email" value="<?= $hr->email;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput" class="form-label">Skills</label>
                                <input type="text" class="form-control" name="skills" value="<?=$hr->skills;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput" class="form-label">Company Address:</label>
                                <select name="companyaddress" class="form-control" placeholder="companyaddress" value="<?= $hr->companyaddress;?>">
                                    <option value="" disabled selected hidden></option>
                                    <option value="Ahmedabad" name="Ahmedabad"
                                        <?php if($hr->companyaddress=="Ahmedabad"){echo "selected";}?>>Ahmedabad</option>
                                    <option value="Andhra pradesh" name="Andhra pradesh"
                                        <?php if($hr->companyaddress=="Andhra pradesh"){echo "selected";}?>>Andhra pradesh
                                    </option>
                                    <option value="Bangalore" name="Bangalore"
                                        <?php if($hr->companyaddress=="Bangalore"){echo "selected";}?>>Bangalore</option>
                                    <option value="Chennai" name="Chennai"
                                        <?php if($hr->companyaddress=="Chennai"){echo "selected";}?>>Chennai</option>
                                    <option value="Hyderabad" name="Hyderabad"
                                        <?php if($hr->companyaddress=="Hyderabad"){echo "selected";}?>>Hyderabad</option>
                                    <option value="Kolkata" name="Kolkata"
                                        <?php if($hr->companyaddress=="Kolkata"){echo "selected";}?>>Kolkata</option>
                                    <option value="Mumbai" name="Mumbai"
                                        <?php if($hr->companyaddress=="Mumbai"){echo "selected";}?>>Mumbai</option>
                                    <option value="New Delhi" name="New Delhi"
                                        <?php if($hr->companyaddress=="New Delhi"){echo "selected";}?>>New Delhi</option>
                                    <option value="Noida" name="Noida"
                                        <?php if($hr->companyaddress=="Noida"){echo "selected";}?>>Noida</option>
                                    <option value="Pune" name="Pune" <?php if($hr->companyaddress=="Pune"){echo "selected";}?>>
                                        pune</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput" class="form-label">Company Type:</label>
                                <select name="companytype" class="form-control" placeholder="Select industry"
                                    value="<?= $hr->companytype;?>" required>
                                    <option value="" disabled selected hidden></option>
                                    <option value="Accounting" name="Accounting"
                                        <?php if($hr->companytype=="Accounting"){echo "selected";}?>>Accounting</option>
                                    <option value="BPO/Call Centre" name="BPO/Call Centre"
                                        <?php if($hr->companytype=="BPO/Call Centre"){echo "selected";}?>>BPO/Call
                                        Centre</option>
                                    <option value="Digital Marketing" name="Digital Marketing"
                                        <?php if($hr->companytype=="Digital Marketing"){echo "selected";}?>>Digital
                                        Marketing</option>
                                    <option value="Education/Teaching" name="Education/Teaching"
                                        <?php if($hr->companytype=="Education/Teaching"){echo "selected";}?>>
                                        Education/Teaching</option>
                                    <option value="Government" name="Government"
                                        <?php if($hr->companytype=="Government"){echo "selected";}?>>Government</option>
                                    <option value="Hotels/Restaurants" name="Hotels/Restaurants"
                                        <?php if($hr->companytype=="Hotels/Restaurants"){echo "selected";}?>>
                                        Hotels/Restaurants</option>
                                    <option value="IT Hardware/Networking" name="IT Hardware/Networking"
                                        <?php if($hr->companytype=="IT Hardware/Networking"){echo "selected";}?>>IT
                                        Hardware/Networking</option>
                                    <option value="IT Software" name="IT Software"
                                        <?php if($hr->companytype=="IT Software"){echo "selected";}?>>IT Software
                                    </option>
                                    <option value="Hr Recuritment" name="Hr Recuritment"
                                        <?php if($hr->companytype=="Recuritment"){echo "selected";}?>>Recuritment
                                    </option>
                                    <option value="Texttiles/Fashion" name="Texttiles/Fashion"
                                        <?php if($hr->companytype=="Texttiles/Fashion"){echo "selected";}?>>
                                        Texttiles/Fashion</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput" class="form-label">pincode:</label>
                                <input type="text" class="form-control" name="pincode" value="<?= $hr->pincode;?>">
                            </div>
                        </div>
                        <div class="row">
                            <?php if($this->session->flashdata('status'));?>
                            <div class="alert alert-success" style="background: white; border: 0px solid white;">
                                <?= $this->session->flashdata('status');?>
                            </div>
                            <?php  ?>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-danger" name="hrregister">SAVE</button>
                        </div>

                        <?php } ?>
                    </form>
                    <!-- ==========================================================Image -->
                    <form action="<?= base_url('hrController/uploadimage/'.$hr->hrid)?>" method="POST"
                        enctype="multipart/form-data">

                        <div class="modal fade" id="image" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        Update Image
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-sm-6">
                                            <label for="exampleFormControlInput" class="Form-label">Image</label>
                                            <input type="hidden" name="img" value="<?=$hr->img;?>">
                                            <input type="file" class="form-control" name="img">
                                            <small><?php if(isset($error)){ echo $error; }?></small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-default" name="uploadimage">Upload
                                            Image</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>
                    <!-- =====================================================change password===== -->
                    <form action="<?= base_url('hrController/changepassword/'.$hr->hrid)?>" method="POST"
                        enctype="multipart/form-data">

                        <a href="" class="message" data-toggle="modal" data-target="#password">Change Password</a>

                        <div class="modal fade" id="password" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        Change Password
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-sm-row">
                                            <label for="exampleFormControlInput3" class="form-label"> Old
                                                Password:</label>
                                            <input type="password" class="form-control" name="old_password"
                                                value="<?=$hr->password;?>">
                                        </div>
                                        <div class="col-sm-row">
                                            <label for="exampleFormControlInput3" class="form-label"> New
                                                Password:</label>
                                            <input type="password" class="form-control" name="newpassword">
                                        </div>
                                        <div class="col-sm-row">
                                            <label for="exampleFormControlInput3" class="form-label"> Confirm
                                                Password:</label>
                                            <input type="password" class="form-control" name="re_password">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-default" name="changepassword">Update
                                            Password</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-3">

        </div>
    </div>
    </div>

</body>

</html>