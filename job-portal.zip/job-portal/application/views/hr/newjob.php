<style>
.add-job {
    margin-top: 70px;
}

.add-job .row {
    margin-left: -3px;
}

.header-row {
    text-align: center;
    color: #5182a7;
    font-size: 120%;
}

.row {
    text-align: left;
    color: #e78217;
    font-size: 16px;
}

#submit_job {
    margin: 10px 0px 30px 0px;
}
</style>
<section class="add-job">
    <div class='col-xs-12 col-sm-12 col-md-12 col-lg-12 row'>
        <div class="col-xs-0 col-sm-2 col-md-3 col-lg-3"></div>
        <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6">
            <div class="form">
                <h3>Post New Job</h3>
                <form class="post_job" name="post_job" method='post' action='<?php echo base_url();?>hrController/newjob' enctype="multipart/form-data">
                    <div class="form-group row">
                        <p>Job Title:</p>
                        <input type="text" name='title' id='title' class='form-control' placeholder="Job Title"
                            required />
                    </div>
                    <div class="form-group row">
                        <p>Company Name:</p>
                        <input type="text" name='company' class='form-control' placeholder="Company Name" required />
                    </div>

                    <div class="form-group row">
                        <p>Location:</p>
                        <select name="location" class="form-control" placeholder="location">
                            <option value="" disabled selected hidden></option>
                            <option value="Ahmedabad" name="Ahmedabad">Ahmedabad</option>
                            <option value="Andhra pradesh" name="Andhra pradesh">Andhra pradesh</option>
                            <option value="Bangalore" name="Bangalore">Bangalore</option>
                            <option value="Chennai" name="Chennai"> Chennai</option>
                            <option value="Hyderabad" name="Hyderabad">Hyderabad</option>
                            <option value="Kolkata" name="Kolkata">Kolkata</option>
                            <option value="Mumbai" name="Mumbai">Mumbai</option>
                            <option value="New Delhi" name="New Delhi">New Delhi</option>
                            <option value="Noida" name="Noida">Noida</option>
                            <option value="Pune" name="Pune">pune</option>
                        </select>
                    </div>

                    <div class="form-group row">
                        <p>Job Description:</p>
                        <textarea name='description' class='form-control' placeholder="Enter job's description"
                            required></textarea>
                    </div>

                    <div class="form-group row">
                        <p>Responsibilities:</p>
                        <textarea name='responsibilities' class='form-control'
                            placeholder="Enter all the responsibilities for the job" required></textarea>
                    </div>
                    <div class="form-group row">
                        <p>Qualification:</p>
                        <textarea name='qualification' class='form-control'
                            placeholder="Enter all the qualification for the job" required></textarea>
                    </div>
                    <div class="form-group row">
                        <p>Skills Required:</p>
                        <textarea name='skills' class='form-control' placeholder="List out requirements for the job"
                            required></textarea>
                    </div>

                    <div class="form-group row">
                        <p>Benefits:</p>
                        <textarea name='benefits' class='form-control'
                            placeholder="Add benefits of working with the company/job" required></textarea>
                    </div>

                    <div class="form-group row">
                        <p>Salary $(per annum):</p>
                        <div class='col-sm-6' style='padding: 0;padding-right: 10px'>
                            <input type="number" name='salary_min' class='form-control' placeholder="Minimum" />
                        </div>
                        <div class='col-sm-6' style='padding: 0;padding-left: 10px'>
                        <input type="number" name='salary_max' class='form-control' placeholder="Max" /></div>
                    </div>

                    <div class="form-group row">
                        <p>Job Duration:</p>
                        <select name='duration' class='form-control'>
                            <option value='Full time'>Full time</option>
                            <option value='Part time'>Part time</option>
                        </select>
                    </div>

                    <div class="form-group row">
                        <p>Contact Email:</p>
                        <input type="email" name='contact_email' class='form-control'
                            placeholder="Enter company's email" required />
                    </div>

                    <div class="form-group row">
                        <p>Expiry Date</p>
                        <input type="date" name='expires' class='datepicker form-control'
                            placeholder="Expiry Date for Vacancy Ex: year-month-date" required />
                    </div>
                    <div>
                        <input type="text" name='created_by' hidden value="<?=$this->session->hrid?>">
                        <button type="submit" class="btn btn-danger" name="newjob">POST JOB VACANCY</button>
                    </div>
            </div>
        </div>
    </div>
</section>