<style>
.add-job {
    margin-top: 70px;
}

.add-job .row {
    margin-left: -3px;
}

.header-row {
    text-align: center;
    color: #5182a7;
    font-size: 120%;
}

.row {
    text-align: left;
    color: #e78217;
    font-size: 16px;
}

#submit_job {
    margin: 10px 0px 30px 0px;
}
</style>

<section class="add-job">
    <div class='col-xs-12 col-sm-12 col-md-12 col-lg-12 row'>
        <div class="col-xs-0 col-sm-2 col-md-3 col-lg-3"></div>
        <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6">
            <div class="form">
                <h3>Post New Job</h3>
                <form class="post_job" name="post_job" method='post' action="<?=base_url('hrController/updatejob/'.$jobs->job_id)?>" enctype="multipart/form-data">
                    <div class="form-group row">
                        <p>Job Title:</p>
                        <input type="text" name='title' id='title' class='form-control' placeholder="Job Title"
                            value="<?=$jobs->title?>" required />
                    </div>
                    <div class="form-group row">
                        <p>Company Name:</p>
                        <input type="text" name='company' class='form-control' placeholder="Company Name"
                            value="<?=$jobs->company?>" required />
                    </div>

                    <div class="form-group row">
                        <p>Location:</p>
                        <select name="location" class="form-control" placeholder="location" values=<?=$jobs->location?>>
                            <option value="" disabled selected hidden></option>
                            <option value="Ahmedabad" name="Ahmedabad"
                                <?php if($jobs->location=="Ahmedabad"){echo "selected";}?>>Ahmedabad</option>
                            <option value="Andhra pradesh" name="Andhra pradesh"
                                <?php if($jobs->location=="Andhra pradesh"){echo "selected";}?>>Andhra pradesh
                            </option>
                            <option value="Bangalore" name="Bangalore"
                                <?php if($jobs->location=="Bangalore"){echo "selected";}?>>Bangalore</option>
                            <option value="Chennai" name="Chennai" <?php if($jobs->location=="Chennai"){echo "selected";}?>>
                                Chennai</option>
                            <option value="Hyderabad" name="Hyderabad"
                                <?php if($jobs->location=="Hyderabad"){echo "selected";}?>>Hyderabad</option>
                            <option value="Kolkata" name="Kolkata" <?php if($jobs->location=="Kolkata"){echo "selected";}?>>
                                Kolkata</option>
                            <option value="Mumbai" name="Mumbai" <?php if($jobs->location=="Mumbai"){echo "selected";}?>>
                                Mumbai</option>
                            <option value="New Delhi" name="New Delhi"
                                <?php if($jobs->location=="New Delhi"){echo "selected";}?>>New Delhi</option>
                            <option value="Noida" name="Noida" <?php if($jobs->location=="Noida"){echo "selected";}?>>Noida
                            </option>
                            <option value="Pune" name="Pune" <?php if($jobs->location=="Pune"){echo "selected";}?>>
                                pune</option>
                        </select>
                    </div>

                    <div class="form-group row">
                        <p>Job Description:</p>
                        <textarea name='description' class='form-control' placeholder="Enter job's description" required><?=$jobs->description?></textarea>
                    </div>

                    <div class="form-group row">
                        <p>Responsibilities:</p>
                        <textarea name='responsibilities' class='form-control'
                            placeholder="Enter all the responsibilities for the job" required><?=$jobs->responsibilities?></textarea>
                    </div>
                    <div class="form-group row">
                        <p>Qualification:</p>
                        <textarea name='qualification' class='form-control'
                            placeholder="Enter all the qualification for the job" required><?=$jobs->qualification?></textarea>
                    </div>
                    <div class="form-group row">
                        <p>Skills Required:</p>
                        <textarea name='skills' class='form-control' placeholder="List out requirements for the job" required><?=$jobs->skills?></textarea>
                    </div>

                    <div class="form-group row">
                        <p>Benefits:</p>
                        <textarea name='benefits' class='form-control'
                            placeholder="Add benefits of working with the company/job"
                            required><?=$jobs->benefits?></textarea>
                    </div>

                    <div class="form-group row">
                        <p>Salary $(per annum):</p>
                        <div class='col-sm-6' style='padding: 0;padding-right: 10px'>
                            <input type="number" name='salary_min' class='form-control' value="<?=$jobs->salary_min?>"
                                placeholder="Minimum" />
                        </div>
                        <div class='col-sm-6' style='padding: 0;padding-left: 10px'>
                            <input type="number" name='salary_max' class='form-control' value="<?=$jobs->salary_max?>"
                                placeholder="Max" />
                        </div>
                    </div>

                    <div class="form-group row">
                        <p>Job Duration:</p>
                        <select name='duration' class='form-control' values=<?=$jobs->duration?>>
                            <option value='Full time' name="Full time"
                                <?php if($jobs->duration=="Full time"){echo "selected";}?>>Full time</option>
                            <option value='Part time' name="Part time"
                                <?php if($jobs->duration=="Part time"){echo "selected";}?>>Part time</option>
                        </select>
                    </div>

                    <div class="form-group row">
                        <p>Contact Email:</p>
                        <input type="email" name='contact_email' class='form-control' value="<?=$jobs->contact_email?>"
                            placeholder="Enter company's email" required />
                    </div>

                    <div class="form-group row">
                        <p>Expiry Date</p>
                        <input type="date" name='expires' class='datepicker form-control' value="<?=$jobs->expires?>"
                            placeholder="Expiry Date for Vacancy Ex: year-month-date" required />
                    </div>
                    <div>
                        <input type="text" name='created_by' hidden value="<?=$this->session->hrid?>">
                        <button type="submit" class="btn btn-danger" name="updatejob">Update job</button>
                    </div>
            </div>
        </div>
    </div>
</section>