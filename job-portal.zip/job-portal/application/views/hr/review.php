<style>
.review {
    margin-top: 70px;
    font: 12pt Georgia, "Times New Roman", Times, serif;
line-height: 1.3;
}
th{
    /* background-color: blue; */
    padding: 10px;
    color: white;
}
#view{
    background: #2b5876;
    background: -webkit-linear-gradient(to right, #4e4376, #2b5876);
    background: linear-gradient(to right, #4e4376, #2b5876);
    color: white;
}
</style>
<div class="review">
    <div class="container">
        <h3>Reviews</h3>
        <div class="col-sm-12 col-lg-12">
            <table border="1" cellpadding="3" cellspacing="2">
                <div class="container">
                    <tr class="theader" id="view">
                        <th width="5%">SNo.</th>
                        <th width="20%">Job Title</th>
                        <th width="15%">Employee Name</th>
                        <th width="15%">Email</th>
                        <th width="10%">Mobile No</th>
                        <th width="10%">City</th>
                        <th width="20%">Resume</th>
                    </tr>
                    <?php 
                    $i = 0;
                    foreach ($applied as $apply) { 
                        $i++;
				?>
                    <tr>
                        <td><?php echo $i; ?></td>

                        <td><?php
					 $job_id = $apply->job_id;
					 $row = $this->db->where("job_id",$job_id)->get("jobs")->result();
						echo ($row[0]->title);
					  ?></td>

                        <td><?php
					 $id = $apply->id;
					 $row = $this->db->where("id",$id)->get("employee")->result();
						echo ($row[0]->name);
					  ?></td>

                        <td><?php
					 $id = $apply->id;?>
                     <a href=""><?php echo ($row[0]->email);?></a>
						</td>

                        <td><?php
					 $id = $apply->id;
						echo ($row[0]->mobile);
					  ?></td>

                        <td><?php
					 $id = $apply->id;
						echo ($row[0]->city);
					  ?></td>

                        <td><?php
					 $id = $apply->id;?> 
                     <a href="<?=base_url()?>assets/file/<?=$row[0]->resume?>"><?php echo ($row[0]->resume);?> </a> <?php
					  ?> </td>

                        <td hidden><?php 
					 $job_id = $apply->job_id;
					//  $row = $this->db->where("job_id",$job_id)->get("jobs")->result();
						echo ($row[0]->created_by);
					  ?></td>

                    <?php } ?>

                </div>
            </table>
        </div>
    </div>
</div>