<style>
body {
    font-family: sans-serif;
    background-color: #f6f6f6;
}

.row {
    padding: 20px;
}

.top-title {
    margin-top: 70px;
    text-align: center;
    padding: 20px;
    background-image: linear-gradient( 109.6deg,  rgba(48,207,208,1) 11.2%, rgba(51,8,103,1) 92.5% );
    color: white;
}

.most .card {
    /* box-shadow: 2px 2px 6px #000000; */
    box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;
    width: 100%;
    height: 60%;
    background-color: white;
}

.most .card-header {
    padding: 30px;

}

.most .col-lg-4 {
    padding: 10px;
}

.most .card-body {
    padding: 10px;
}

.most .subscription {
    font-size: 11px;
    color: #999;
    font-weight: 400;
    padding: 10px 2px;
}

.most .price {
    color: red;
}

.most .know {
    float: right;
}

#carddetails {
    background-color: blue;
    padding: 20px;
    color: white;
    width: 100%;
    height: 590px;
    /* background: #614385;
    background: -webkit-linear-gradient(to right, #516395, #614385);
    background: linear-gradient(to right, #516395, #614385); */
    background-image: linear-gradient( 109.6deg,  rgba(48,207,208,1) 11.2%, rgba(51,8,103,1) 92.5% );

}

#carddetails p {
    padding: 30px;
}

.feedback .card {
    box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 2px 6px 2px;
    background-color: white;
}

#forms {
    padding: 20px;
}

#btn {
    margin-left: 130px;
    margin-top: -30px;
}
</style>
</head>

<body>
    <div class="container">
        <div class="top-title">
            <h2>Move ahead in career, faster</h2>
            <h4>with our paid services</h4>
        </div>
        <div class="most">
            <div class="row">
                <?php foreach ($paid as $paid):?>
                <div class="col-sm-4 col-lg-4">
                    <div class="card">
                        <div class="card-header">
                            <img src="<?=base_url('post/'.$paid->img) ?>" alt="img" class="img"
                                style="width: 100%; height: 140px">
                        </div>
                        <div class="card-body">
                            <p><?php echo $paid->postname?></p>
                            <h4><?php echo $paid->title?></h4>
                            <span><?php echo $paid->details?></span>
                            <div class="subscription">
                                Subscription starts from
                            </div>
                            <span class="price"> &#x20B9;<?php echo $paid->price?> </span>
                            <span class="subscription">for <?php echo $paid->months?> months</span>
                            <div class="know"><a href="">KNOW MORE</a></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="feedback">
        <div class="container">
            <div class="row">
                <div class="col-sm-1"></div>
                <div class="feed">
                    <div class="col-sm-5 col-lg-5 col-md-5">
                        <div class="card" id="carddetails">
                            <p>Talk to Us</p>
                            <p>call us Toll Free:1800-102-5557</p>
                            <p>9:00am to 9:00am</p>
                            <p>For Bulk queries call: 18001034477</p>
                        </div>
                    </div>
                    <div class="col-sm-5 col-lg-5 col-md-5">
                        <div class="card" id="forms">
                            <h3>CONTACT US</h3>
                            <p>
                                Our executive will get in touch with you soon</p>
                            <form action="<?=base_url();?>homeController/feedback" method="post">
                                <div class="form-group">
                                    <label for="">Name:</label>
                                    <input type="text" class="form-control" name="name"><br>
                                </div>
                                <div class="form-group">
                                    <label for="">Email:</label>
                                    <input type="text" class="form-control" name="email"><br>
                                </div>
                                <div class="form-group">
                                    <label for="">Mobile:</label>
                                    <input type="text" class="form-control" name="mobile"><br>
                                </div>
                                <div class="form-group">
                                    <label for="">Write your query here:</label>
                                    <textarea type="text" class="form-control" name="query"></textarea>
                                </div>
                                <?php if($this->session->flashdata('status'));?>
                                <div class="alert alert-success" style="background: white; border: 0px solid white;">
                                    <?= $this->session->flashdata('status');?>
                                </div>
                                <?php  ?>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-danger" name="feedback"
                                        id="btn">Submit</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
        </div>
    </div>
</body>