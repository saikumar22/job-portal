<style>
body {
    font: 12pt Georgia, "Times New Roman", Times, serif;
    line-height: 1.3;
}

.company {
    margin-top: 70px;
}

.company .subtitle {
    font-size: 20px;
    padding: 10px;
}

a:hover {
    list-style: none;
    text-decoration: none;
    color: red;
}

.company .card-header {
    /* background-color: #666; */
    color: black;
    padding: 5px;
}

footer {
    margin-top: 210px;
}
</style>
<div class="company">
    <div class="container">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-5 col-md-5 pull-left">
                        <h3>Browse Jobs by Companies</h3>
                    </div>

                    <div class="col-sm-3 col-md-3 pull-right">
                        <form action="<?php echo site_url('#');?>" class="navbar-form" role="search" method="get">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search" name="keyword">
                                <div class="input-group-btn">
                                    <button class="btn btn-default" type="submit" value="search"><i
                                            class="glyphicon glyphicon-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="companyname">
            <div class="col-sm-8">
                <div class="card">
                    <?php
                    foreach ($jobs as $job) { ?>
                    <div class="subtitle">
                        <span class="fa fa-building"></span>
                        <a href="<?php echo base_url();?>empController/companydata?c=<?=$job?>"> <?php echo $job;?></a>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>