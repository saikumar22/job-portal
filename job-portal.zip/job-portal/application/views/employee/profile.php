<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
.navbar-brand {
    width: 100px;
}

body {
    background: -webkit-linear-gradient(to left, #B06AB3, #4568DC);
    background: linear-gradient(to left, #B06AB3, #4568DC);
}

.card {
    padding: 30px;
    margin-top: 100px;
    background-color: white;
}

.col-sm-6 {
    padding: 10px;
}

.card-header {
    text-align: center;
}

#empprofile .btn {
    margin-left: 180px;
}

.row {
    margin-top: 20px;
}

h5 {
    font-size: 20px;
}
</style>

<body>
    <div class="container" id="empprofile">
        <div class="row">
            <div class="col-sm-3">
            </div>
            <div class="col-sm-6">
                <div class="card">
                    <h5><b>Edit Profile Details</b></h5>
                    <hr>
                    <?php foreach ($employee as $emp) {  ?>
                    <form action="<?= base_url('empController/updatedetails/'.$emp->id)?>" method="POST"
                        enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput1" class="form-label">Name:</label>
                                <input type="text" class="form-control" name="name" value="<?=$emp->name;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput2" class="form-label">Email:</label>
                                <input type="email" class="form-control" name="email" value="<?= $emp->email;?>">
                            </div>
                            <div class="col-sm-6">
                                <label for="exampleFormControlInput4" class="form-label">Mobile:</label>
                                <input type="text" class="form-control" name="mobile" value="<?= $emp->mobile;?>">
                            </div>

                            <div class="col-sm-6">
                                <label for="exampleFormControlInput5" class="form-label">Current city:</label>
                                <select name="city" class="form-control" placeholder="city" value="<?= $emp->city;?>">
                                    <option value="" disabled selected hidden></option>
                                    <option value="Ahmedabad" name="Ahmedabad"
                                        <?php if($emp->city=="Ahmedabad"){echo "selected";}?>>Ahmedabad</option>
                                    <option value="Andhra pradesh" name="Andhra pradesh"
                                        <?php if($emp->city=="Andhra pradesh"){echo "selected";}?>>Andhra pradesh
                                    </option>
                                    <option value="Bangalore" name="Bangalore"
                                        <?php if($emp->city=="Bangalore"){echo "selected";}?>>Bangalore</option>
                                    <option value="Chennai" name="Chennai"
                                        <?php if($emp->city=="Chennai"){echo "selected";}?>>Chennai</option>
                                    <option value="Hyderabad" name="Hyderabad"
                                        <?php if($emp->city=="Hyderabad"){echo "selected";}?>>Hyderabad</option>
                                    <option value="Kolkata" name="Kolkata"
                                        <?php if($emp->city=="Kolkata"){echo "selected";}?>>Kolkata</option>
                                    <option value="Mumbai" name="Mumbai"
                                        <?php if($emp->city=="Mumbai"){echo "selected";}?>>Mumbai</option>
                                    <option value="New Delhi" name="New Delhi"
                                        <?php if($emp->city=="New Delhi"){echo "selected";}?>>New Delhi</option>
                                    <option value="Noida" name="Noida"
                                        <?php if($emp->city=="Noida"){echo "selected";}?>>Noida</option>
                                    <option value="Pune" name="Pune" <?php if($emp->city=="Pune"){echo "selected";}?>>
                                        pune</option>
                                </select>
                            </div>
                            <div class="col-sm-12" style="margin-top: 20px;">
                                <a href="<?=base_url($emp->path)?>" target="_blank">Show my resume</a>
                            </div>
                        </div>

                        <div class="col-sm-6 col-md-6">
                            <button type="submit" class="btn btn-danger" name="signup">Update Profile</button>
                        </div>
                        <?php } ?>
                        <div class="row" style="margin: -20px 0px -50px -200px;">
                            <div class="col-sm-2 col-md-6">
                                <button type="button" class="btn btn-default" data-toggle="modal"
                                    data-target="#resume">Resume</button>
                            </div>
                            <div class="col-sm-2">
                                <button type="button" class="btn btn-default" data-toggle="modal"
                                    data-target="#emp_password">Change
                                    Password</button>
                            </div>
                        </div>
                        <div style="margin-top: 53px;">
                            <?php if($this->session->flashdata('status'));?>
                            <span class="alert alert-success"
                                style="color: blue; background-color:white; border:0px solid white;">
                                <?= $this->session->flashdata('status');?>
                            </span>
                            <?php  ?>
                        </div>

                    </form>

                    <!-- =================================== resume -->
                    <div class="row">
                        <div class="col-sm-3">
                            <form action="<?= base_url('empController/updateresume/'.$emp->id)?>" method="POST"
                                style="margin-left: -120px;" enctype="multipart/form-data">

                                <div class="modal fade" id="resume" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close"
                                                    data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Update Resume</h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="col-sm-8">
                                                    <label for="exampleFormControlInput6" class="form-label"
                                                        required>Resume:</label>
                                                    <input type="file" name="resume">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-default" name="updateresume">Update
                                                    Resume</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- ==================================  change password  -->
                    <form action="<?= base_url('empController/change_password/'.$emp->id)?>" method="POST"
                        enctype="multipart/form-data">

                        <div class="modal fade" id="emp_password" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        Change
                                        Password
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-sm-row">
                                            <label for="exampleFormControlInput3" class="form-label"> Old
                                                Password:</label>
                                            <input type="password" class="form-control" name="old_password"
                                                value="<?= $emp->password;?>">
                                        </div>
                                        <div class="col-sm-row">
                                            <label for="exampleFormControlInput3" class="form-label"> New
                                                Password:</label>
                                            <input type="password" class="form-control" name="newpassword">
                                        </div>
                                        <div class="col-sm-row">
                                            <label for="exampleFormControlInput3" class="form-label"> Confirm
                                                Password:</label>
                                            <input type="password" class="form-control" name="re_password">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-default" name="change_password">Update
                                            Password</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-3">
    </div>
    </div>
    </div>
</body>

</html>