
<style>
    .submenu{
        margin-top: 50px;
        background-color: white;
      }
	  .card{
    	margin-top: 20px;
    	width: 100%;
	    background-color: #f4f4f4;
  	  padding:10px;
    }
    .card-header{
    	margin-left: 35px;
    	font-family: 14px Roboto sans-serif;
    }
    .nav-tabs li{
      font-family: 14px Roboto sans-serif;

    }
    
  li{
  	 	list-style: none;
    }
  button{
   	float: right;
    }
  body{
   	color:#666666;
  }
  
</style>
</head>

<body>
<div class="submenu">
	<div class="container-field">
		<!-- <h3>Top Recruiters</h3> -->
		<ul class="nav nav-tabs">
			<li class="active"><a href="#">All Jobs</a></li>
			<li><a href="./Govt. jobs.html">Govt. Jobs</a></li>
			<li><a href="./Walk-in jobs.html">Walk-in Jobs</a></li>
		</ul>
	</div>
</div>
<div class="jobs">
<div class="container">
    <div class="row">
      <div class="col-sm-6">
        <div class="card">
        	<div class="card-header">
        		Browse Jobs by Functional Areas
        	</div>
        	<hr>
          <div class="row">
            <div class="col-sm-6">
              <ul>
								<li>Bank Jobs</li>
								<li>Data Entry Jobs</li>
								<li>HR Jobs</li>
							</ul>
            </div>
            <div class="col-sm-6">
              <ul>
								<li>Teacher Jobs</li>
								<li>Legal Jobs</li>
								<li>Marketing Jobs</li>
							</ul>
            </div>
          
          <div class="col-sm-9">
          	<button type="button" class="btn btn-link" ><a href="#">View all functional areas</a></button>
          	</div>
        	</div>
        </div>
      </div>

      <div class="col-sm-6">
        <div class="card">
        <div class="card-header">
           	Browse Jobs by Industries
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6">
              <ul>
								<li>Govt Jobs</li>
								<li>Railway Jobs</li>
								<li>Ngo Jobs</li>
							</ul>
            </div>
            <div class="col-sm-6">
              <ul>
								<li>Agriculture Jobs</li>
								<li>Telecom Jobs</li>
								<li>Shipping Jobs</li>
							</ul>
            </div>
          
            <div class="col-sm-9">
          <button type="button" class="btn btn-link" ><a href="#">View all functional areas</a></button>
        </div>
      </div>
		</div>
</div>
</div>
</div>

<div class="container"> 
<div class="row">    
     <div class="col-sm-6">
        <div class="card">
        <div class="card-header">
           	Browse Jobs by Designation
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6">
              <ul>
								<li>Company Secretary Jobs</li>
								<li>Business Analyst Jobs</li>
								<li>Lecturer Jobs</li>
							</ul>
            </div>
            <div class="col-sm-6">
              <ul>
								<li>Oracle Jobs</li>
								<li>Telecom Jobs</li>
								<li>Shipping Jobs</li>
							</ul>
            </div>

            <div class="col-sm-9">
          <button type="button" class="btn btn-link" ><a href="#">View all functional areas</a></button>
        </div>
      </div>
    </div>
  </div>

  <div class="col-sm-6">
        <div class="card">
        <div class="card-header">
           	Browse Jobs by Skills
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6">
              <ul>
								<li>Biotechnology Jobs</li>
								<li>Software testing Jobs</li>
								<li>Nursing Jobs</li>
							</ul>
            </div>
            <div class="col-sm-6">
              <ul>
								<li>SAP Jobs</li>
								<li>Animation Jobs</li>
								<li>.Net Jobs</li>
							</ul>
            </div>

            <div class="col-sm-9">
          <button type="button" class="btn btn-link" ><a href="#">View all functional areas</a></button>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</body>
