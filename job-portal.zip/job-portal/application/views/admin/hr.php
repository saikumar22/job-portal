<style>
#jobsview{
    margin-top: 30px;
}
.theader{
    background-color: blue;
    color: white;
}
</style>
<div class="hrdetails">
    <div class="container" id="jobsview">
        <div class="row">
            <div class="col-md">
                <table class="table">
                    <div>
                        <h4><b>HR Details</b></h4>
                    </div>
                    <div class="view">
                        <theader>
                            <tr class="theader">
                                <td>Id</td>
                                <td>Image</td>
                                <td>Name</td>
                                <td>Email</td>
                                <td>Password</td>
                                <td>Company Name</td>
                                <td>role</td>
                            </tr>
                        </theader>
                        <tbody>
                            <?php foreach ($hr as $hr):?>
                            <tr>
                                <td><?= $hr->hrid ?></td>
                                <td>
                                <img src="<?= base_url('images/' . $hr->img) ?>" alt="img" style="width: 50px;">
                                </td>
                                <td><?php echo $hr->name;?></td>
                                <td><?php echo $hr->email;?></td>
                                <td><?php echo $hr->password?></td>
                                <td><?php echo $hr->companyname?></td>
                                <td><?php echo $hr->role?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </div>
            </div>
        </div>
    </div>

