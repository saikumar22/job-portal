<style>
#jobsview{
    margin-top: 30px;
}
.theader{
    background-color: blue;
    color: white;
}
</style>
<div class="container">
        <form class="form" action="<?php echo base_url('hrController/index') ?>" method="post">
            <div class="header">
                <!-- <h5 style="mahrin-top: 70px"> Welcome <?=$this->session->name?></h5>
                <h5><?=$this->session->hrid?></h5> -->

            </div>
        </form>
    </div>
    <div class="container" id="jobsview">
        <div class="row">
            <div class="col-md">
                <table class="table">
                    <div>
                        <h4><b>Feedback Details</b></h4>
                    </div>
                    <div class="view">
                        <theader>
                            <tr class="theader">
                                <td>Id</td>
                                <td>Name</td>
                                <td>Email</td>
                                <td>Mobile</td>
                                <td>Querys</td>
                            </tr>
                        </theader>
                        <tbody>
                            <?php foreach ($feedback as $fb):?>
                            <tr>
                                <td><?= $fb->feedbackid ?></td>
                                <td><?php echo $fb->name;?></td>
                                <td><?php echo $fb->email;?></td>
                                <td><?php echo $fb->mobile;?></td>
                                <td><?php echo $fb->query;?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </div>
            </div>
        </div>
    </div>

