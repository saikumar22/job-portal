<style>
.editpost {
    margin-top: 50px;
}

.card {
    border: 1px solid black;
    padding: 10px;
}

.row {
    padding: 10px;
}

.btn {
    margin-left: 200px;
    margin-top: 30px;
}

.back {
    margin-top: -60px;
    float: right;
}

.card-body {
    padding: 20px;
}
</style>
</head>

<body>
    <div class="editpost">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">

                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-header">
                            <h4>Edit paid post Details</h4>
                            <div class="back"><a href="<?=base_url('adminController/post')?>"
                                    class="btn btn-danger btn-sm float-end">Back</a></div>
                        </div>
                        <div class="card-body">
                            <form action="<?= base_url('adminController/update/'.$paid->postid)?>" method="POST"
                                enctype="multipart/form-data">
                                <div class="row">
                                    <label for="exampleFormControlInput1" class="form-label">Post Name:</label>
                                    <input type="text" class="form-control" name="postname"
                                        value="<?= $paid->postname;?>">
                                </div>
                                <div class="row">
                                    <label for="exampleFormControlInput2" class="form-label">Title:</label>
                                    <input type="text" class="form-control" name="title" value="<?= $paid->title;?>">
                                </div>
                                <div class="row">
                                    <label for="exampleFormControlInput3" class="form-label">Details:</label>
                                    <input type="text" class="form-control" name="details"
                                        value="<?= $paid->details;?>">
                                </div>
                                <div class="row">
                                    <label for="exampleFormControlInput4" class="form-label">Price:</label>
                                    <input type="text" class="form-control" name="price" value="<?= $paid->price;?>">
                                </div>
                                <div class="row">
                                    <label for="exampleFormControlInput4" class="form-label">Months:</label>
                                    <input type="text" class="form-control" name="months" value="<?= $paid->months;?>">
                                </div>

                                <div class="row">
                                    <label for="exampleFormControlInput6" class="form-label">Image:</label>
                                    <img src="<?=base_url('post/'.$paid->img)?>" class="w-100" alt="Image">
                                    <input type="hidden" name="old_img" value="<?=$paid->img;?>">
                                    <input type="file" class="form-control" name="img">
                                </div>
                                <?php if($this->session->flashdata('status'));?>
                                <div class="alert alert-success" style="background: white; border: 0px solid white;">
                                    <?= $this->session->flashdata('status');?>
                                </div>
                                <?php  ?>
                                <div>
                                    <button type="submit" class="btn btn-info px-4 float-end"
                                        name="post_save">Update</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">

                </div>
            </div>
        </div>
    </div>
</body>

</html>