<head>
    <style>
    body {
        font-family: Roboto, sans-serif;
        background-color: #f6f6f6;
    }

    .col-sm-8 {
        width: 100%;
    }

    .linktag1 a {
        list-style: none;
        text-decoration: none;
        color: black;
    }

    .linktag1 a:hover {
        text-decoration: none;
    }

    .star a {
        list-style: none;
        color: red;
        margin: 5px;
    }

    .star a:hover {
        text-decoration: none;
    }

    .glyphicon-star {
        color: #ff8703;
    }

    .title {
        font-size: 16px;
        text-decoration: none;
        color: #091e42;
    }

    .subtitle {
        font-size: 15px;
        color: #091e42;
        padding-top: 4px;
    }

    .subtitle2,
    .job,
    .cells {
        font-size: 12px;
        color: #14171a;
        margin-top: 15px;
    }

    .card {
        width: 100%;
        padding: 10px;
        padding-bottom: 40px;
        margin-bottom: 20px;
        border: 1px solid black;
        background-color: white;
        /* text-decoration: none; */
    }

    #row {
        margin-top: 80px;
        /* padding: 20px; */
    }

    .job-description {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 12px;
        padding: 5px;
    }
    .input-group{
        width: 150%;
    }
    #search{
        margin-right: 100px;
    }
    </style>
</head>
<div class="search">

</div>
<div class="govtjobs">
    <div class="container">
        <div class="row" id="row">
            <div class="col-sm-3 col-md-3 pull-left">
                <h4> <b>Jobs</b></h4>
            </div>
            <div class="col-sm-3 col-md-3 pull-right" id="search">
            <form action="<?php echo site_url('homeController/search_keyword');?>" class="navbar-form" role="search" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Designation" name="keyword">
                        <div class="input-group-btn">
                            <button class="btn btn-default" type="submit" value="search"><i class="glyphicon glyphicon-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2"> </div>
            <?php foreach ($jobs as $job) { ?>
            <div class="col-sm-8">
                <section class="linktag1">
                    <a href="<?=base_url("adminController/jobview/".$job->job_id)?>">
                        <div class="card">
                            <div class="title">
                                <b><?php echo $job->title;?></b>
                            </div>
                            <div class="subtitle">
                                <span class="fa fa-building"></span>
                                <?php echo $job->company;?><span class="glyphicon glyphicon-star"></span> (5 Reviews)
                            </div>
                            <div class="subtitle2">
                                <span class="glyphicon glyphicon-education"></span> <?php echo $job->qualification;?>
                                &emsp; <i class="fa fa-inr"></i>Not disclosed&emsp;<span
                                    class="glyphicon glyphicon-map-marker"></span><?php echo $job->location?>
                            </div>
                            <div class="job-description">
                                <i class="glyphicon glyphicon-file"></i>
                                <?php echo $job->description;?>
                            </div>
                            <div class="tags for jobs">
                                <div class="cells">
                                    <div class="col-md-2">
                                        Create date:
                                        <?php echo $job->date_created;?>
                                    </div>

                                    <div class="col-sm-2">
                                        <span class="fa fa-clock-o ">
                                            Duration:
                                            <?php echo $job->duration;?>
                                        </span>
                                    </div>
                                    <div class="col-md-2">
                                        <span class="fa fa-hourglass-half">
                                            Expires:
                                            <?php echo $job->expires;?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </section>
            </div>
            <?php } ?>
            <div class="col-sm-2"> </div>
        </div>
    </div>
</div>