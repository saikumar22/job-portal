<style>
#jobsview{
    margin-top: 30px;
}
.theader{
    background-color: blue;
    color: white;
}
</style>
<div class="container">
    <div class="container" id="jobsview">
        <div class="row">
            <div class="col-md">
                <table class="table">
                    <div>
                        <h4><b>Employee Details</b></h4>
                    </div>
                    <div class="view">
                        <theader>
                            <tr class="theader">
                                <td>Id</td>
                                <td>Name</td>
                                <td>Email</td>
                                <td>Password</td>
                                <td>Mobile</td>
                                <td>Resume</td>
                                <!-- <td>Edit</td>
                                <td>Delete</td> -->
                            </tr>
                        </theader>
                        <tbody>
                            <?php foreach ($employee as $hr):?>
                            <tr>
                                <td><?= $hr->id ?></td>
                                <td><?php echo $hr->name;?></td>
                                <td><?php echo $hr->email;?></td>
                                <td><?php echo $hr->password;?></td>
                                <td><?php echo $hr->mobile;?></td>
                                <td><a href="<?=base_url()?><?=$hr->path?>"><?php echo ($hr->path);?> </a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </div>
            </div>
        </div>
    </div>

