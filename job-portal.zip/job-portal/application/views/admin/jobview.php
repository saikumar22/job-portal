<style>
.single_job {
    margin-top: 80px;
	background-color: white;
	padding: 20px;
}

.actions {
    cursor: pointer;
    padding: 5px;
}

.container {
    /* width: 100%; */
    line-height: 1.5;
}

.fa1 {
    font-size: 80%;
    margin: 0 7px 0 0;
    color: #86898c;
}

.new-point {
    font-size: 115%;
    color: #5182ba;
    margin: 10px 0;
    text-decoration: underline;
	text-decoration: none;
}

.bullets {
    list-style-type: disc;
}

.divider1 {
    width: 100%;
    border-bottom: 1px solid #ccc;
    margin: 14px 0px;
}

.job-icon {
    margin: 8px 0;
    width: 50px;
    height: 50px;
    background: #ff8a65;
    color: #fff;
    font-size: 200%;
    text-align: center;
    padding: 2px 3px;
    text-shadow: 1px 1px 1px #737373;
}

.job-title {
    font-size: 130%;
}
.job-description, .job-qualification{
	margin: 0px 30px;
}
.job_location_header{
	color: #8c8a8a;
    font-size: 93%;
	margin-left: -32px;
}
.fa-clock-o{
	color: #8c8a8a;
    font-size: 93%;
	margin-left: -16px;
}
.job-duration{
	color: #8c8a8a;
    font-size: 93%;
	margin-left: -29px;
}
.job-company,
.job-location,
.job-salary,
.job-duration,
.job-expires,
.job-created_by {
    color: #8c8a8a;
    font-size: 93%;
    line-height: 1.5;
    display: inline-block;
    padding: 0;
}
.submit{
    text-align: center;
}
</style>
<section class='single_job'>
    <div class='container'>
        <div class='row col-sm-12 col-md-12 col-lg-12'>
            <div class='  col-sm-1 col-md-1 col-lg-1'></div>
            <div class='job-section  col-sm-10 col-md-10 col-lg-10'>
                <?php 	if(isset($title)) {
					if(isset($created_by) && isset($this->session->userdata('user')->hrid)) {?>
					
                <?php }  ?> 
                <div class='row'>
                    <div class='p0 col-sm-12 col-md-12'>
                        <div class='p0 col-sm-2 col-lg-1'>
                            <div class='job-icon'><?php echo ucfirst($title[0]);?></div>
                        </div>
                        <div class='col-sm-10 col-lg-11'>
                            <div>
                                <div class='job-title '><?=$title?></div>
                                <div class='job-company'><i class='fa1 fa fa-building'></i><?=$company?></div>
                                <div class='p0 col-sm-12 col-md-12'>
                                    <div class='p0 job_location_header col-sm-5 col-md-2 col-lg-2 '><i
                                        class='fa1 fa fa-map-marker fa-2'></i>&nbsp;<?=$location?></div>
                                    <div class='p0 job-salary col-sm-5 col-md-9 col-lg-10'><i
                                        class='fa1 fa fa-rupee'></i><?=$salary_min?> - <?=$salary_max?>
									</div>
                                </div>
                                <div class='p0 col-sm-12 col-md-12'>
                                    <div class='p0 job-expires col-sm-5 col-md-2 col-lg-2'><i
                                            class='fa1 fa fa-clock-o'></i><?=$duration?></div>
                                    <div class='p0 job-duration col-sm-5 col-md-9 col-lg-10'><i
                                            class='fa1 fa fa-hourglass-half '></i><?=$expires?></div>
                                </div>
                                <div class='p0 job-created_by col-sm-12 col-md-12'><i class='fa1 fa fa-user'></i>Posted By <?=$name?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class='divider1'></div>

                <div class='row'>
                    <div class='p0 col-sm-1 col-lg-1'></div>
                    <div class='col-sm-11 col-lg-11'>
                        <div class='new-point'>Job Description:</div>
                        <div class='job-description'><?=$description?></div>
                        <div class='new-point'>Job Responsibilities:</div>
                        <div class='pre-wrap job-responsibilities'><?=$responsibilities?></div>
						<div class='new-point'>Job Qualification:</div>
                        <div class='pre-wrap job-qualification'><?=$qualification?></div>
                        <div class='new-point'>Skills & Expertise :</div>
                        <div class='pre-wrap job-skills'><?=$skills?></div>
                        <div class='new-point'>Benefits:</div>
                        <div class='pre-wrap job-benefits'><?=$benefits?></div>
                        <div class='new-point'>Contact Email:</div>
                        <div class='job-contact'><i class='fa1 fa fa-envelope '></i> <?=$contact_email?></div>
                        <div class="submit">
                    </div>
                </div>
                <?php } else { 	echo "<div style='text-align: center;margin-top: 100px;font-size: 120%;color: #585755;'>No data found</div>"; } ?>
            </div>
            <div class=' col-sm-1 col-md-1 col-lg-1'></div>
        </div>
    </div>
</section>