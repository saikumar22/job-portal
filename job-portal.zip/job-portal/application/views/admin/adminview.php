<style>
#jobsview{
    margin-top: 30px;
}
.theader{
    background-color: blue;
    color: white;
}
</style>
<div class="container">
        <form class="form" action="<?php echo base_url('hrController/index') ?>" method="post">
            <div class="header">
                <!-- <h5 style="margin-top: 70px"> Welcome <?=$this->session->name?></h5>
                <h5><?=$this->session->hrid?></h5> -->

            </div>
        </form>
    </div>
    <div class="container" id="jobsview">
        <div class="row">
            <div class="col-md">
                <table class="table">
                    <div>
                        <h4><b>List of Jobs</b></h4>
                        <h6 colspan="5" align="right" style="margin-top: -40px"><a href="<?=base_url("adminController/addpost")?>" class="btn btn-success btn-sm">New Post</a></h6>
                    </div>
                    <div class="view">
                        <theader>
                            <tr class="theader">
                                <td>Id</td>
                                <td>Image</td>
                                <td>Post Name</td>
                                <td>Title</td>
                                <td>Description</td>
                                <td>Price</td>
                                <td>Months</td>
                                <td>Edit</td>
                                <td>Delete</td>
                            </tr>
                        </theader>
                        <tbody>
                            <?php foreach ($paid as $g => $rg):?>
                            <tr>
                                <td><?= $rg->postid ?></td>
                                <td>
                                    <img src="<?=base_url('post/'.$rg->img) ?>" height="40px" width="70px" alt="img">
                                </td>
                                <td><?php echo $rg->postname?></td>
                                <td><?php echo $rg->title;?></td>
                                <td><?php echo $rg->details?></td>
                                <td><?php echo $rg->price?></td>
                                <td><?php echo $rg->months?></td>
                                <td><a href="<?=base_url("adminController/edit/".$rg->postid)?>"
                                        class="btn btn-success btn-sm">Edit</a></td>
                                <td><a href="<?=base_url("adminController/delete/".$rg->postid)?>"
                                        class="btn btn-danger btn-sm">Delete</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </div>
            </div>
        </div>
    </div>

