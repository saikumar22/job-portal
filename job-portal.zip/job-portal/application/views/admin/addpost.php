<style>
.row{
    margin-top: 20px;
}
    .card {
        border: 1px solid black;
        padding: 30px;
        margin-top: 40px;
    }
    .card-header {
        text-align: center;
    } 
    .btn {
        margin-left: 100px;
        margin-top: 30px;
    }
    </style>
</head>
<body>
<div class="container">
        <div class="row">
            <div class="col-sm-4">
            </div>
            <div class="col-sm-4">
                <div class="card">
                <div class="card-header">
                <h3></h3>
            </div>
            <div class="card-body">
                <?php echo form_open_multipart('adminController/submit');?>
                    <div class="row">
                        <label for="exampleFormControlInput1" class="form-label">Post Name:</label>
                        <input type="text" class="form-control" name="postname">
                    </div>
                    <div class="row">
                        <label for="exampleFormControlInput2" class="form-label">Title:</label>
                        <input type="text" class="form-control" name="title">
                    </div>
                    <div class="row">
                        <label for="exampleFormControlInput3" class="form-label">Details:</label>
                        <input type="text" class="form-control" name="details">
                    </div>
                    <div class="row">
                        <label for="exampleFormControlInput4" class="form-label">Price:</label>
                        <input type="text" class="form-control" name="price">
                    </div>
                    <div class="row">
                        <label for="exampleFormControlInput4" class="form-label">Months:</label>
                        <input type="text" class="form-control" name="months">
                    </div>
                
                    <div class="row">
                        <label for="exampleFormControlInput6" class="form-label">Image:</label>
                        <input type="file" name="img">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-danger" name="submit">Submit</button>
                    </div>
            </div>
        </div>
                </div>
            </div>
            <div class="col-4">
            </div>
        </div>
    </div>
</body>

</html>