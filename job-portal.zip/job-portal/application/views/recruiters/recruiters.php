<style>
body {
    /* background-color: rgba(156, 156, 156, 0.4); */
    background-color: #f6f6f6;

}

.submenu {
    margin-top: 60px;
    background-color: white;
}

.Recruiters {
    margin-top: 70px;
}

.Recruiters .card {
    margin-top: 10px;
    margin-left: 0px;
    background-color: white;
    padding: 10px;
    width: 100%;
    height: 100%;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
}

.Recruiters .details {
    margin-left: 30px;
}

.Recruiters .col-lg-10 a {
    margin-left: 140px;
}

.Recruiters .btn-info {
    margin-left: 20px;
    color: white;
}

.Recruiters .img {
    width: 50%;
    margin-left: 20px;
    height: 100px;
}

.Recruiters .message {
    float: right;
}

.Recruiters .container {
    margin-bottom: 10px;
}
</style>
<!-- RECRUITERS -->
<div class="Recruiters">
    <div class="container">
        <div class="row">
            <?php
            foreach ($hr as $hr) {  ?>
            <div class="col-sm-6">
                <div class="card">
                    <div class="row">
                        <div class="col-sm-4" id="images">
                            <img src="<?= base_url('images/' . $hr->img) ?>" alt="img" class="img">
                        </div>
                        <div class="col-sm-8">
                            <a href=""><?= $hr->name; ?></a>
                            <p><span class="glyphicon glyphicon-education"></span><?= $hr->role; ?></p>
                            <p><?= $hr->companyname; ?></p>
                            <p><span class="glyphicon glyphicon-map-marker"></span><?= $hr->companyaddress; ?></p>
                        </div>
                        <div class="details">
                            <p>Skills/Roles I hire for :</p>
                            <h5><?= $hr->skills; ?></h5>
                            <p>Last active on 12-Jul-2016</p>

                        </div>
                        <div class="bottom">
                            <div class="col-sm-4 col-lg-4 col-xs-4 col-md-6">

                                <?php
                      $result =  $this->db->where(["id"=>$this->session->id,"hrid"=>$hr->hrid])->get("follow")->result();

                                  if ($result) { ?>
                                <form action="<?php echo base_url("homeController/unfollow"); ?>" method="POST">
                                    <input type="text" name="fid" value="<?= $result[0]->fid ?>" hidden>
                                    <input type="submit" class="btn btn-info" value="Following" name="follow">
                                </form>

                                <?php } else { ?>
                                <form action="<?php echo base_url("homeController/follow"); ?>" method="POST">
                                    <input type="text" name="id" value="<?= $this->session->id ?>" hidden>
                                    <input type="text" name="hrid" value="<?= $hr->hrid ?>" hidden>
                                    <input type="submit" class="btn btn-info" value="Follow" name="follow">
                                </form>
                                <?php } ?>

                            </div>
                            <div class="col-lg-8">
                                <input type="text" name="id" value="<?= $this->session->id ?>" hidden>
                                <input type="text" name="hrid" value="<?= $hr->hrid ?>"hidden >
                                <a href="" class="message" data-toggle="modal" data-target="#message"><span
                                        class="glyphicon glyphicon-send"></span> Send
                                    Message</a>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="message" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <div class="row">
                                <div class="col-sm-6 col-lg-6">

                                    <h5 class="modal-title" style="color:red"><?= $hr->name;?></h5>
                                    <p><?= $hr->role;?></p>
                                    <p><?= $hr->companyname;?></p>
                                    <p><?= $hr->companyaddress;?></p>
                                </div>
                                <div class="col-sm-2 col-lg-2">
                                    <img src="<?= base_url('images/' . $hr->img) ?>" alt="img" class="img"
                                        style="width: 100%;">
                                </div>
                            </div>
                        </div>
                        <div class="modal-body">
                        </div>
                        <div class="modal-footer">
                            <input type="text" name="text">
                            <button type="button" class="btn btn-default">send</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
            

        </div>
    </div>
</div>