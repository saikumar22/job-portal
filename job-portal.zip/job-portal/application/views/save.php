<style>
body{
    font-size: 18px;
}
.table{
    background-color: white;
}
.applied {
    margin-top: 50px;
}
th{
    background-color: red;
    color: white;
}
footer .container{
    margin-top: 300px;
}
</style>
<div class="applied">
    <div class="container">
        <h2>SAVE JOB LIST</h2>
        <div class="col-sm-12 col-lg-12">
        <table border="1" cellpadding="3" cellspacing="2">
            <div class="container">
                <tr class="theader">
                    <th width="5%">SNo.</th>
                    <th width="30%">Title Name</th>
                    <th width="35%">Company Name</th>
                    <th width="30%">Last Date</th>
                    <!-- <th width="15%">Applied Time</th> -->
                </tr>
                <?php 
                    $i = 0;
                    foreach ($jobsave as $save) { 
                        $i++;
				?>
                <tr>
                    <td><?php echo $i; ?></td>

                    <td><?php
					 $job_id = $save->job_id;
					 $row = $this->db->where("job_id",$job_id)->get("jobs")->result();
						echo ($row[0]->title);
					  ?></td>

                    <td><?php
					 $job_id = $save->job_id;
						echo ($row[0]->company);
					  ?></td>
                    
                    <td><?php 
                    $job_id = $save->job_id;
						echo ($row[0]->expires);
                    ?></td>

                    <td hidden><?php 
					 $job_id = $save->job_id;
						echo ($row[0]->created_by);
					  ?></td>

                <?php } ?>

            </div>
        </table>
        </div>
    </div>

</div>