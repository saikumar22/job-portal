<style>
#jobsview{
    margin-top: 30px;
}
#view{
    background: #2b5876;
    background: -webkit-linear-gradient(to right, #4e4376, #2b5876);
    background: linear-gradient(to right, #4e4376, #2b5876);
    color: white;
}
</style>
<div class="container">
        <form class="form" action="<?php echo base_url('hrController/index') ?>" method="post">
            <div class="header">
                <!-- <h5 style="margin-top: 70px"> Welcome <?=$this->session->name?></h5>
                <h5><?=$this->session->hrid?></h5> -->

            </div>
        </form>
    </div>
    <div class="container" id="jobsview">
        <div class="row">
            <div class="col-md">
                <table class="table">
                    <div>
                        <h4><b>List of Jobs</b></h4>
                        <h6 colspan="5" align="right" style="margin-top: -40px"><a href="<?=base_url("hrController/job")?>" class="btn btn-success btn-sm">Post New Job</a></h6>
                    </div>
                    <div class="view">
                        <theader>
                            <tr class="theader" id="view">
                                <td>Id</td>
                                <td>Title</td>
                                <td>Location</td>
                                <td>Date of Created</td>
                                <td>Expired</td>
                                <td>Deleted</td>
                                <td>View</td>
                                <td>Edit</td>
                                <td>Delete</td>
                            </tr>
                        </theader>
                        <tbody>
                            <?php foreach ($jobs as $job => $rg):?>
                            <tr>
                                <td><?= $rg->job_id ?></td>
                                <td><?php echo $rg->title?></td>
                                <td><?php echo $rg->location;?></td>
                                <td><?php echo $rg->date_created?></td>
                                <td><?php echo $rg->expires?></td>
                                <td><?php echo $rg->deleted;?></td>
                                <td><a href="<?=base_url("hrController/View/".$rg->job_id)?>"class="btn btn-success btn-sm">view</a></td>
                                <td><a href="<?=base_url("hrController/edit/".$rg->job_id)?>"class="btn btn-primary btn-sm">Edit</a></td>
                                <td><a href="<?=base_url("hrController/Delete/".$rg->job_id)?>"class="btn btn-danger btn-sm">Delete</a></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                    </div>
            </div>
        </div>
    </div>

