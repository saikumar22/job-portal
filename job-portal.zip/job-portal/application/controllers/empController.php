<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class empController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url','form');
        $this->load->model('empModel');
    }
    
    public function index(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("web/footer");
    }
    public function profile(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
		$data['employee'] =$this->db->where("id",$_SESSION['id'])->get("employee")->result();
        $this->load->view('employee/profile', $data);

    }
    public function updatedetails($id){
        $this->form_validation->set_rules('name', 'name', 'required');
        $this->form_validation->set_rules('mobile', 'mobile', 'required');
        $this->form_validation->set_rules('city', 'city', 'required');
        // $this->load->helper('file');

        // $config['upload_path']   = './assets/file/';
        // $config['allowed_types'] = 'gif|jpg|png|pdf';
        // $config['max_size']      = 10240;
        // $this->load->library('upload', $config);

        // if($this->upload->do_upload('resume'))
        // {
        //     $this->upload->data("file_name");
            $data=[
                "name"=>$this->input->post("name"),
                "mobile"=>$this->input->post("mobile"),
                "city"=>$this->input->post("city"),
                // "resume"=>$this->upload->data('file_name')    
            ];
            $emp = new empModel;
            $res = $emp->updateEmp($data, $id);
            $this->session->set_flashdata('status','Profile Update Successfully');
            redirect(base_url('empController/profile/'.$id));
        
    }

    public function singlejob($job_id){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $data = $this->empModel->get_job($job_id);
        $data = (array) $data;
        $this->load->view("singlejob",$data);
        $this->load->view("web/footer");
    }

    public function applied(){
        if($this->session->id)
        {
            $test = $this->db->where([
                'job_id' => $this->input->post('job_id'),
                'id' => $this->input->post('id'),
                'hrid' => $this->input->post('hrid')
            ])->get("applied")->num_rows();
           
                if($test==0){
                    $this->load->view("web/header");
                    $this->load->view("web/navbar");
                    $insert = [
                        'job_id' => $this->input->post('job_id'),
                        'id' => $this->input->post('id'),
                        'hrid' => $this->input->post('hrid')
                    ];
                    $this->db->insert("applied",$insert);
                    $data['applied'] =$this->db->where("id",$this->session->id)->order_by("applied_date", "desc")->get("applied")->result();
                    $this->load->view("employee/applied",$data);
                    $this->load->view("web/footer");
                }else{
                    echo "Already applied";
                }
        }else{
            redirect("homeController/emplogin");
        }
    }
    
    public function appliedview(){
        $this->load->view('web/header');
        $this->load->view("web/navbar");
        $result["applied"] = $this->db->where("id",$this->session->id)->order_by("applied_date", "desc")->get("applied")->result();
        $this->load->view('employee/applied',$result);
        $this->load->view('web/footer');
    }
    public function companies(){
        $this->load->view('web/header');
        $this->load->view('web/navbar');
		$data =$this->db->order_by("company", "asc")->get("jobs")->result();
             $i=0;
        foreach($data as $row){
            $array[$i]  = $row->company;
             $i++;
        }
       $newarray["jobs"]= array_unique($array);
        $this->load->view('companies',$newarray);
        $this->load->view('web/footer');
    }

    public function companydata(){
        $data['jobs'] =$this->db->where("company",$this->input->get("c"))->get("jobs")->result();
        $this->load->view('web/header');
        $this->load->view('web/navbar');
        $this->load->view('companydata',$data);
        $this->load->view('web/footer');
    }

    public function change_password(){
		$pass=$this->input->post('old_password');
    	$npass=$this->input->post('newpassword');
    	$rpass=$this->input->post('re_password');
    if($npass!=$rpass){ 
		echo '<script type="text/javascript">'; 
		echo 'alert("unable to change password");'; 
		echo 'window.location.href = "../profile";';
		echo '</script>';
    }else{
        $this->db->select('*');
        $this->db->from('employee');
        $this->db->where('id',$this->session->userdata('id'));
        $this->db->where('password',$pass);
        $query = $this->db->get();
        if($query->num_rows()==1){
            $data = array(
                           'password' => $npass
                        );
            $this->db->where('id', $this->session->userdata('id'));
            $this->db->update('employee', $data); 
		echo '<script type="text/javascript">'; 
		echo 'alert("Password Update success");'; 
		echo 'window.location.href = "../profile";';
		echo '</script>';
        }else{
            return "false";
        }
    }
	}
    public function updateresume($id){
        $config['upload_path']   = './assets/file/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        $config['max_size']      = 10240;
        $this->load->library('upload', $config);

        if($this->upload->do_upload('resume'))
        {
            $resume = $this->upload->data("file_name");
            $data=[    
                "resume"=>$resume
            ];
            $re= $this->db->where("id",$this->session->id)->get("employee")->row();
            echo $re->resume;
            $path = "./assets/file/".$re->resume;
            unlink($path);
            $id=$this->input->post("id");
            $u = $this->db->where('id',$id)->update("employee",$data);
            redirect(base_url('empController/profile/1'.$id));
        }else{
                echo "error";
            }
    }

}