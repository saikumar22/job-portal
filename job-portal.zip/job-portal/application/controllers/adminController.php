<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class adminController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url','form');
        $this->load->model('adminModel');
    }
    
    public function index(){
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_message('required', 'Enter %s');
        if($this->form_validation->run() === FALSE)
        {  
        $this->load->view('admin/signin');
        }
        else
        {   
        $data = array(
        'email' => $this->input->post('email'),
        'password' =>($this->input->post('password')),
        );
       
        $check = $this->adminModel->adminLogin($data);
        if($check != false){
        $user = array(
        'aid' => $check->aid,
        'email' => $check->email,
        'name' => $check->name
        );
        
        $this->session->set_userdata($user);
        $_SESSION["name"]=$user["name"];
        $_SESSION["aid"]=$user["aid"];
    
        redirect(base_url('adminController/post')); 
        }
        echo "please enter valid email and password";
        // $this->load->view('admin/signin');
    }
    }
    public function post(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
        // $this->load->view("admin/dashboard");
        $data['paid']=$this->db->get("paid")->result();
        $this->load->view("admin/adminview",$data);
    }
    public function addpost(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
        $this->load->view("admin/addpost");
    }
    public function submit(){
        $this->form_validation->set_rules('postname','postname','required');
        $this->form_validation->set_rules('title','title','required');
        $this->form_validation->set_rules('details','details','required');
        $this->form_validation->set_rules('price','price','required');
        $this->form_validation->set_rules('months','months','required');
    
        if($this->form_validation->run()){
            $ori_filename = $_FILES['img']['name'];
            $new_name = time()."".str_replace(' ','-',$ori_filename);
            $config=[
                'upload_path' => './post/',
                'allowed_types'=>'gif|jpg|png',
                'file_name'=> $new_name,
            ];
            $this->load->library('upload',$config);
            if ( ! $this->upload->do_upload('img'))
            {
                $imageError = array('error' => $this->upload->display_errors());
                $this->load->view('admin/addpost', $imageError);
            }
            else
            {
                $prod_filename = $this->upload->data('file_name');
                $data=[
                    'postname'=>$this->input->post('postname'),
                    'title'=>$this->input->post('title'),
                    'details'=>$this->input->post('details'),
                    'price'=>$this->input->post('price'),
                    'months'=>$this->input->post('months'),
                    'img'=>$prod_filename
                ];
                $post = new adminModel;
                $res = $post->insertpost($data);
                $this->session->set_flashdata('status','Add Inserted Successfully');
                redirect(base_url('adminController/index'));
            }
        }
        else{
            $this->addpost();
        }
    }
    public function edit($id){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
        $paid = new adminModel;
        $data['paid']=$paid->editPost($id);
        $this->load->view('admin/postedit', $data);
    }
    public function update($id){
        $this->form_validation->set_rules('postname','postname','required');
        $this->form_validation->set_rules('title','title','required');
        $this->form_validation->set_rules('details','details','required');
        $this->form_validation->set_rules('price','price','required');
        $this->form_validation->set_rules('months','months','required');
    
        if($this->form_validation->run()){
            $old_filename = $this->input->post('old_img');
            $new_filename = $_FILES['img']['name'];
    
            if($new_filename == TRUE){
    
                $update_filename = time()."-".str_replace(' ','-',$_FILES['img']['name']);
                $config=[
                    'upload_path' => './post/',
                    'allowed_types'=>'gif|jpg|png',
                    'file_name'=> $update_filename,
                ];
            $this->load->library('upload',$config);
            if ($this->upload->do_upload('img'))
            {
                if(file_exists('./post/'.$old_filename)){
                    unlink('./post/'.$old_filename);
                }
            }
        }
        else{
            $update_filename = $old_filename;
        }
            $data=[
                'postname'=>$this->input->post('postname'),
                'title'=>$this->input->post('title'),
                'details'=>$this->input->post('details'),
                'price'=>$this->input->post('price'),
                'months'=>$this->input->post('months'),
                'img'=>$update_filename
            ];
            $products = new adminModel;
            $res = $products->updatePost($data, $id);
            $this->session->set_flashdata('status','Post Update Successfully');
            redirect(base_url('adminController/edit/'.$id));
        }
        else{
            return $this->edit($id);
        }
    }
    
    public function delete($id){
        $paid = new adminModel;
        if($paid->checkPostImage($id)){
            $data = $paid->checkPostImage($id);
            if(file_exists('./post/'.$data->img)){
                unlink('./post/'.$data->img);
            }
            $paid->deletePost($id);
            $this->session->set_flashdata('status',' Data and Image seleted Successfully');
            redirect(base_url('adminController/index'));
        } 
    }
    public function jobs(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
        $data['jobs'] =$this->db->order_by("job_id", "desc")->get("jobs")->result();
        $this->load->view("admin/jobs",$data);
    }
    public function hr(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
		$data['hr'] =$this->db->get("hr")->result();
        $this->load->view("admin/hr",$data);
    }
    public function employee(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
		$data['employee'] =$this->db->get("employee")->result();
        $this->load->view("admin/employee",$data);
    }
    public function jobview($job_id){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
        $data = $this->adminModel->get_job($job_id);
        $data = (array) $data;
        $this->load->view("admin/jobview",$data);
    }
    public function paidreview(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
        $this->load->view("admin/paidreview");
    }
    public function feedback(){
        $this->load->view("web/header");
        $this->load->view("web/adminnavbar");
		$data['feedback'] =$this->db->get("feedback")->result();
        $this->load->view("admin/feedback",$data);
    }
}