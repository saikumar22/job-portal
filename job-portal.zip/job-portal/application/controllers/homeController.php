<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class homeController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('registerModel');
        $this->load->library(array('form_validation','session'));
    }
    public function  index(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $data['jobs'] =$this->db->order_by("job_id", "desc")->get("jobs")->result();
        $this->load->view("home",$data);
        $this->load->view("web/footer");
    }
    public function hrLogin(){
        $this->load->view("hr/signin");
    }
    public function hrsignup(){
        $this->load->view("hr/signup");
    }
    public function emplogin(){
        $this->load->view("employee/signin");
    }
    public function empsignup(){
        $this->load->view("employee/signup");
    }

    public function empRegister(){
    $this->form_validation->set_rules('name', 'name', 'required');
    $this->form_validation->set_rules('email', 'email', 'required');
    $this->form_validation->set_rules('mobile', 'mobile', 'required');
    $this->form_validation->set_rules('password', 'password', 'required');
    $this->form_validation->set_rules('city', 'city', 'required');
    $this->load->helper('file');

    $config['upload_path']   = './assets/file/';
    $config['allowed_types'] = 'gif|jpg|png|pdf';
    $config['max_size']      = 10240;
    $this->load->library('upload', $config);

    if($this->upload->do_upload('resume'))
    {
        $this->upload->data("file_name");
        
        $data = [
            "name"=>$this->input->post("name"),
            "email"=>$this->input->post("email"),
            "mobile"=>$this->input->post("mobile"),
            "password"=>$this->input->post("password"),
            "city"=>$this->input->post("city"),
            "path"=>"assets/file/".$this->upload->data('file_name') ,
            "resume"=>$this->upload->data('file_name')    
        ];
        $check = $this->registerModel->insert_empregister($data);
    if($check != false){
    $users = array(
    'id' => $check,
    'email' => $this->input->post('email'),
    'name' => $this->input->post('name'),
    'mobile' => $this->input->post('mobile'),
    'resume' => $this->input->post('resume')
    );
    }
    $this->session->set_userdata($users);
    redirect(base_url('homeController/emplogin') ); 
    }
    else
    {
        echo  $this->upload->display_errors();
    }
}
    
public function empSignin(){
    $this->form_validation->set_rules('email', 'email', 'required');
    $this->form_validation->set_rules('password', 'password', 'required');
    $this->form_validation->set_message('required', 'Enter %s');
    if($this->form_validation->run() === FALSE)
    {  
    $this->load->view('home');
    }
    else
    {   
    $data = array(
    'email' => $this->input->post('email'),
    'password' =>($this->input->post('password')),
    );
    $check = $this->registerModel->empLogin($data);
    if($check != false){
    $user = array(
    'id' => $check->id,
    'email' => $check->email,
    'name' => $check->name,
    'mobile' => $check->mobile,
    'resume' => $check->resume

    );
    $this->session->set_userdata($user);
    $_SESSION["name"]=$user["name"];
    $_SESSION["id"]=$user["id"];
    redirect( base_url('homeController/index') ); 
    }
    $this->load->view('employee/signin');
    }
}

public function hrRegister(){
    $this->form_validation->set_rules('name', 'name', 'required');
    $this->form_validation->set_rules('email', 'email', 'required');
    $this->form_validation->set_rules('mobile', 'mobile', 'required');
    $this->form_validation->set_rules('password', 'password', 'required');
    $this->form_validation->set_rules('companyname', 'companyname', 'required');
    $this->form_validation->set_rules('companytype', 'companytype', 'required');
    $this->form_validation->set_rules('pincode', 'pincode', 'required');
	$hr_status = 'active';
   
    if($this->form_validation->run() === FALSE)
    {  
    $this->load->view('home');
    }
    else
    {   
    $data = array(
    'name' => $this->input->post('name'),
    'email' => $this->input->post('email'),
    'mobile' => $this->input->post('mobile'),
    'password' =>$this->input->post('password'),
    'companyname' =>$this->input->post('companyname'),
    'companytype' =>$this->input->post('companytype'),
    'companyaddress' =>$this->input->post('companyaddress'),
    'pincode' =>$this->input->post('pincode'),
    'hr_status' => $hr_status

    );
    $check = $this->registerModel->insert_hrRegister($data);
    if($check != false){
    $users = array(
    'hrid' => $check,
    'email' => $this->input->post('email'),
    'name' => $this->input->post('name')
    );
    }
    $this->session->set_userdata($users);
    $this->session->set_userdata('login_status','register_success');
    redirect(base_url('homeController/hrLogin')); 
    }
}

public function hrSignin(){
    $this->form_validation->set_rules('email', 'email', 'required');
    $this->form_validation->set_rules('password', 'password', 'required');
    $this->form_validation->set_message('required', 'Enter %s');
    if($this->form_validation->run() === FALSE)
    {  
        $this->load->view('home');
    }
    else
    {   
        $data = array(
        'email' => $this->input->post('email'),
        'password' =>($this->input->post('password')),
        );
   
        $check = $this->registerModel->hrLogin($data);
        if($check != false){
            $user = array(
            'hrid' => $check->hrid,
            'email' => $check->email,
            'name' => $check->name
            );
            $this->session->set_userdata($user);
            $_SESSION["name"]=$user["name"];
            $_SESSION["hrid"]=$user["hrid"];
            $this->registerModel->logoutUser('active','');
            redirect(base_url('hrController/index')); 
        }
        $this->load->view('hr/signin');
    }
}

    public function jobs(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $this->load->view("jobs/jobs");
        $this->load->view("web/footer");
   }
    public function recruiters(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
		$data['hr'] =$this->db->get("hr")->result();
        $this->load->view("recruiters/recruiters",$data);
        $this->load->view("web/footer");
    }

    public function services(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
		$data['paid'] =$this->db->get("paid")->result();
        $this->load->view("services/services",$data);
        $this->load->view("web/footer");
    }

    public function empView(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $data['jobs'] =$this->db->get("jobs")->result();
        $this->load->view("home",$data);
        $this->load->view("web/footer");
    }
    public function search_keyword(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $keyword=$this->input->get('keyword');
        $data['results']=$this->registerModel->search($keyword);
        print_r($data);
        die;
        $this->load->view('searchview',$data);
        $this->load->view("web/footer");
    }
    public function searchkey(){
        $this->load->view("web/header");
        $this->load->view("web/navbar");
        $keyword=$this->input->get('keyword');
        $data['jobs']=$this->registerModel->searchcompany($keyword);
        $this->load->view('companyview',$data);
        $this->load->view("web/footer");
    }
    public function feedback(){
        $this->form_validation->set_rules('name', 'name', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('mobile', 'mobile', 'required');
        $this->form_validation->set_rules('query', 'query', 'required');
   
    if($this->form_validation->run() === FALSE)
    {  
    $this->load->view('home');
    }
    else
    {   
    $data = array(
    'name' => $this->input->post('name'),
    'email' => $this->input->post('email'),
    'mobile' => $this->input->post('mobile'),
    'query' =>$this->input->post('query'),
    );
    $check = $this->registerModel->insert_feedback($data);
    if($check != false){
    $feedback = array(
    'email' => $this->input->post('email'),
    'name' => $this->input->post('name')
    );
    }
    $this->session->set_userdata($feedback);
    $this->session->set_flashdata('status','Feedback Send Successfully');
    redirect(base_url('homeController/services')); 
    }

    }
    // public function message(){
	// 	$data['hr'] =$this->db->get("hr")->result();
    //     $this->load->view("recruiters/recruiters",$data);
    // }
    public function logout(){

        $date = $_POST['date'];
		$this->load->helper('url');
		$this->registerModel->logoutUser('deactive',$date);
		unset(
			$_SESSION['hrid'],
            $_SESSION['id'],
			$_SESSION['username']
		);
		 redirect(base_url());
        // session_destroy();
        // redirect(base_url());
    }   
    public function follow(){
        if($this->session->id)
        {
            $test = $this->db->where([
                'id' => $this->input->post('id'),
                'hrid' => $this->input->post('hrid')
            ])->get("follow")->num_rows();
           
                if($test==0){
                    $insert = [
                        'id' => $this->input->post('id'),
                        'hrid' => $this->input->post('hrid')
                    ];
                    $this->db->insert("follow",$insert);
                    redirect(base_url('homeController/recruiters'));
                }else{
                    echo "You Already Following";
                }
        }else{
            redirect(base_url('homeController/recruiters'));
        }
    }

    public function unfollow(){
         $this->db->where("fid",$this->input->post("fid"))->delete("follow");
         redirect(base_url('homeController/recruiters'));
    }
}