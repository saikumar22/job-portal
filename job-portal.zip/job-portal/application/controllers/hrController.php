<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hrController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url','form');
        $this->load->model('hrModel');
    }
    
    public function index(){
        $this->load->view("web/header");
        $this->load->view("web/hrnavbar");
        if($this->session->userdata('user'))
		$data['tab'] = 'LOGIN';	
		$data['jobs'] =$this->db->where("created_by",$_SESSION['hrid'])->get("jobs")->result();
		// $data['jobs'] =$this->db->get("jobs")->result();
        $this->load->view("dashboard",$data);
    }
    public function profile(){
        $this->load->view("web/header");
        $this->load->view("web/hrnavbar");
		$data['hr'] =$this->db->where("hrid",$_SESSION['hrid'])->get("hr")->result();
        $this->load->view('hr/profile', $data);
    }

    public function update($hrid){
        $this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('role','role','required');
        $this->form_validation->set_rules('mobile', 'mobile', 'required');
        $this->form_validation->set_rules('companyname', 'companyname', 'required');
        $this->form_validation->set_rules('companytype', 'companytype', 'required');
        $this->form_validation->set_rules('pincode', 'pincode', 'required');
		$this->form_validation->set_rules('skills','skills','required');
		
		// $config["upload_path"]="./images";
		// $config["allowed_types"]="png|jpg|gif|pdf";
		// $this->load->library('upload',$config);
		// if($this->upload->do_upload("img")){
		
		// 	$filename	= $this->upload->data("file_name");
		// }else{
		// 	$this->upload->display_errors();
		// }
		$data=[
			'name' => $this->input->post('name'),
			'role' => $this->input->post('role'),
			'mobile' => $this->input->post('mobile'),
			'companyname' =>$this->input->post('companyname'),
			'companytype' =>$this->input->post('companytype'),
			'companyaddress' =>$this->input->post('companyaddress'),
			'pincode' =>$this->input->post('pincode'),
			'skills'=>$this->input->post('skills')
			// 'img'=>$filename
		];
		$hr = new hrModel;
		$res = $hr->updateHr($data, $hrid);
		$this->session->set_flashdata('status','Profile Update Successfully');
		redirect(base_url('hrController/profile/'.$hrid));
    }
	public function job(){
		$this->load->view("web/header");
		$this->load->view("web/hrnavbar");
		$this->load->view("hr/newjob");
	}

	public function newjob(){
		$data=[
			'title' => $this->input->post('title'),
			'company' => $this->input->post('company'),
			'location' => $this->input->post('location'),
			'description' =>$this->input->post('description'),
			'responsibilities' =>$this->input->post('responsibilities'),
			'qualification' =>$this->input->post('qualification'),
			'benefits' =>$this->input->post('benefits'),
			'skills'=>$this->input->post('skills'),
			'salary_min' =>$this->input->post('salary_min'),
			'salary_max' =>$this->input->post('salary_max'),
			'duration' =>$this->input->post('duration'),
			'contact_email' =>$this->input->post('contact_email'),
			'expires'=>$this->input->post('expires'),
			"created_by" => $this->session->hrid,
			'deleted' => 'no',
			'date_created' => date('Y-m-d H:i:s')
		];
		$id = $this->hrModel->postJob($data);
			if(!$id)
				redirect(base_url());
			else
				redirect('hrController/index');
	}

	public function edit($job_id) {
		$this->load->view("web/header");
        $this->load->view("web/hrnavbar");
		$task = new hrModel;
		$data['jobs']=$task->editjob($job_id);
		$this->load->view("hr/updatejob",$data);
	}

	public function updatejob($job_id){
		$data = array(
			'title' => $this->input->post('title'),
			'company' => $this->input->post('company'),
			'location' => $this->input->post('location'),
			'description' =>$this->input->post('description'),
			'responsibilities' =>$this->input->post('responsibilities'),
			'qualification' =>$this->input->post('qualification'),
			'benefits' =>$this->input->post('benefits'),
			'skills'=>$this->input->post('skills'),
			'salary_min' =>$this->input->post('salary_min'),
			'salary_max' =>$this->input->post('salary_max'),
			'duration' =>$this->input->post('duration'),
			'contact_email' =>$this->input->post('contact_email'),
			'expires'=>$this->input->post('expires'),
			"created_by" => $this->session->hrid,
			'deleted' => 'no',
			'date_created' => date('Y-m-d H:i:s')
			);
		unset($data['date_created']);
		$data['date_modified'] = date('Y-m-d H:i:s');
		$result = $this->hrModel->updateJob($data,$job_id);
		$this->session->set_flashdata('status','Profile Update Successfully');
		redirect(base_url('hrController/index/'.$job_id));
		}

	public function View() {
		$job_id = $this->uri->segment(3);	
		$data = $this->hrModel->get_job($job_id);
		$data = (array) $data;
		$data['tab'] = 'SINGLE JOB';
        $this->load->view("web/header",$data);
        $this->load->view("web/hrnavbar");
		$this->load->view('hr/view',$data);
	}

	public function delete($job_id) {
		$delete= $this->hrModel->delete_job($job_id);
        if ($delete) {
            redirect(base_url("hrController/index"));  
            echo "success";      
        }else{
            echo "unable to delete";
        }
	}
	public function review(){
		$this->load->view("web/header");
        $this->load->view("web/hrnavbar");
		$result["applied"] = $this->db->where("hrid",$this->session->hrid)->get("applied")->result();
		$this->load->view("hr/review",$result);
	}
	public function changepassword(){
		$pass=$this->input->post('old_password');
    	$npass=$this->input->post('newpassword');
    	$rpass=$this->input->post('re_password');
    if($npass!=$rpass){ 
		echo '<script type="text/javascript">'; 
		echo 'alert("Place check your new password");'; 
		echo 'window.location.href = "../profile";';
		echo '</script>';

    }else{
        $this->db->select('*');
        $this->db->from('hr');
        $this->db->where('hrid',$this->session->userdata('hrid'));
        $this->db->where('password',$pass);
        $query = $this->db->get();
        if($query->num_rows()==1){
            $data = array(
                           'password' => $npass
                        );
            $this->db->where('hrid', $this->session->userdata('hrid'));
            $this->db->update('hr', $data); 
		echo '<script type="text/javascript">'; 
		echo 'alert("Password Update success");'; 
		echo 'window.location.href = "../profile";';
		echo '</script>';
        }else{
			echo '<script type="text/javascript">'; 
			echo 'alert("please check your Old Password");'; 
			echo 'window.location.href = "../profile";';
			echo '</script>';        }
    }
	}
	public function uploadimage($hrid){
		
		$config["upload_path"]="./images";
		$config["allowed_types"]="png|jpg|gif|pdf";
		$this->load->library('upload',$config);
		if($this->upload->do_upload("img")){
		
			$filename	= $this->upload->data("file_name");
		}else{
			$this->upload->display_errors();
		}
		$data=[
			'img'=>$filename
		];
		$hr = new hrModel;
		$res = $hr->updateHr($data, $hrid);
		redirect(base_url('hrController/profile/'.$hrid));
	}
}