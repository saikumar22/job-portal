-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2021 at 08:39 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `applied`
--

CREATE TABLE `applied` (
  `aid` int(10) NOT NULL,
  `id` int(20) NOT NULL,
  `job_id` int(10) NOT NULL,
  `hrid` int(10) NOT NULL,
  `applied_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applied`
--

INSERT INTO `applied` (`aid`, `id`, `job_id`, `hrid`, `applied_date`) VALUES
(2, 2, 3, 2, '2021-06-29 13:20:00'),
(6, 3, 2, 2, '2021-06-30 14:33:19'),
(11, 1, 1, 1, '2021-06-30 16:37:50'),
(12, 1, 2, 2, '2021-06-30 16:38:39'),
(13, 4, 2, 2, '2021-06-30 17:16:03'),
(18, 1, 26, 2, '2021-07-19 13:29:57');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `cid` int(11) NOT NULL,
  `from_id` int(10) NOT NULL,
  `to_id` int(10) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `city` varchar(50) NOT NULL,
  `resume` varchar(60) NOT NULL,
  `path` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `password`, `mobile`, `city`, `resume`, `path`) VALUES
(1, 'saikumar', 'sai12@gmail.com', '1234', '7894561235', 'Hyderabad', 'saikumar.pdf', 'assets/file/saikumar.pdf'),
(2, 'sathish', 'sat1@gmail.com', 'sat123', '7534219685', 'Hyderabad/Secunderabad', 'Thallapelly_Saikumar3.pdf', 'assets/file/Thallapelly_Saikumar3.pdf'),
(3, 'sai', 'sai@gmail.com', 'sai', '8096651152', 'Hyderabad/Secunderabad', 'saikumar.pdf', 'assets/file/saikumar.pdf'),
(4, 'sathish', 'sathish@gmail.com', '1234', '123467890', 'Hyderabad/Secunderabad', 'saikumar1.pdf', 'assets/file/saikumar1.pdf'),
(5, 'ram', 'ram@gmail.com', '12345', '8596741230', 'Bangalore', 'Saikumar_Thallapelly2.pdf', 'assets/file/Saikumar_Thallapelly2.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedbackid` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `query` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedbackid`, `name`, `email`, `mobile`, `query`) VALUES
(1, 'saikumar', 'sai12@gmail.com', '7894561230', 'good'),
(2, 'sathish', 'sathish@gmail.com', '9874561203', 'my prrofile was not updated');

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

CREATE TABLE `follow` (
  `fid` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `hrid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `follow`
--

INSERT INTO `follow` (`fid`, `id`, `hrid`) VALUES
(36, 2, 4),
(37, 2, 2),
(38, 2, 3),
(46, 1, 3),
(48, 1, 2),
(53, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr`
--

CREATE TABLE `hr` (
  `hrid` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `companyname` varchar(40) NOT NULL,
  `companytype` varchar(100) NOT NULL,
  `pincode` int(10) NOT NULL,
  `companyaddress` varchar(60) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `skills` varchar(200) NOT NULL,
  `img` varchar(60) NOT NULL,
  `role` varchar(40) NOT NULL,
  `date_modified` datetime NOT NULL,
  `last_logout` varchar(30) CHARACTER SET latin1 NOT NULL,
  `hr_status` varchar(10) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hr`
--

INSERT INTO `hr` (`hrid`, `name`, `email`, `password`, `companyname`, `companytype`, `pincode`, `companyaddress`, `mobile`, `skills`, `img`, `role`, `date_modified`, `last_logout`, `hr_status`) VALUES
(1, 'saikumar Thallapelly', 'sai22@gmail.com', '1234', 'Wealus technology solutions pvt ltd', 'IT Software', 500039, 'Hyderabad', '8096651152', 'IT Recruitment, Campus Recruitment, Campus Hiring, Software Testing', '1625117889-saikumar3.jpg', 'Company Recruiter', '2021-07-09 11:53:30', '', 'deactive'),
(2, 'sathish', 'sathish@gmail.com', '1234', 'SBICAP Securities Limited', 'Recuritment', 500039, 'hyderabad', '7539654128', 'Technical, PHP, Web Development, Web Technologies, Wordpress, Javascript, HTML', 's2.png', 'Human Resource Manager', '2021-07-09 01:56:48', '', 'deactive'),
(3, 'rakesh', 'rakesh1@gmail.com', 'rakesh1', 'Tata consultancy services', 'Recuritment', 560066, 'Bangalore', '9874561230', 'Software Development, Business Development', '', 'Associate Manager Human Resources', '2021-07-05 11:56:21', '', ''),
(4, 'sai pilli', 'sai1@gmail.com', 'saipilli1', 'Wipro', 'IT Software', 500039, 'hyderabad', '8899776541', 'Technical, PHP, Web Development, Web Technologies, Wordpress', '', 'Human Resource Manager', '2021-07-07 11:56:11', '', ''),
(6, 'shiva', 'shiva@gmail.com', '1234', 'Accenture Multinational Company', 'Government', 500039, 'Bangalore', '9874561230', 'Software Development, Business Development', '', 'Human Resource Manager', '2021-07-19 13:19:49', '', 'active'),
(7, 'vamshi', 'vamshi@gmail.com', '1234', 'Deloitte Touche Tohmatsu Limited', 'BPO/Call Centre', 50063, 'Chennai', '7894851290', 'Technical, PHP, Web Development, Web Technologies, Wordpress, Javascript, HTML', '', 'Human Resource Manager', '2021-07-07 13:20:03', '', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `company` varchar(50) NOT NULL,
  `location` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `responsibilities` text NOT NULL,
  `skills` text NOT NULL,
  `benefits` text NOT NULL,
  `salary_min` int(11) NOT NULL,
  `salary_max` int(11) NOT NULL,
  `contact_email` varchar(255) NOT NULL,
  `duration` enum('Full time','Part time') NOT NULL,
  `expires` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `deleted` enum('no','yes') NOT NULL,
  `date_created` date NOT NULL,
  `date_modified` datetime NOT NULL,
  `qualification` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `title`, `company`, `location`, `description`, `responsibilities`, `skills`, `benefits`, `salary_min`, `salary_max`, `contact_email`, `duration`, `expires`, `created_by`, `deleted`, `date_created`, `date_modified`, `qualification`) VALUES
(1, 'Programmer Analyst- C#, VB.NET, SQL', 'Wealus technology solutions pvt ltd', 'Chennai', 'Driven by technology-enabled growth and success in business for our clients, we employ unsurpassed methodologies to establish and conquer new realms of global markets. We follow industry’s best business practices and models to deliver deadline-driven, customizable, flexible and scalable business services such as Application Development, Mobile App Development, Cloud and Branding Services.', '<ul class=\'bullets\'><li>Programming, debugging, and documenting complex software applications.</li><li>Developing and implementing web-based solutions.</li><li>Providing technical and strategic advice to Manager, Applications Development and other Broadridge Managers.</li><li>Work with the Product Management team to build project specifications.</li><li>Collaborate with the Change Management team during development to ensure quality code.</li><li>Works with manager and teammates to build accurate estimates for assigned business support and project support development tasks, delivering reliable, reusable and supportable software on time and on-budget.</li><li>Performing other duties as assigned.</li></ul>', '<ul class=\'bullets\'><li>4+ years of experience programming with C#, JavaScript, CSS, and SQL</li><li>B.S. in Computer Science / related field required</li></ul>', '<ul class=\'bullets\'><li>We provide our own working environment with desktop setups.</li></ul>', 250000, 300000, 'sai22@gmail.com', 'Full time', '2021-07-30', 1, 'no', '2021-06-27', '2021-07-19 11:00:28', 'B.E./B.Tech/MCA with specialization in Computers/Electronics/IT OR M.Sc in Computer Science/IT'),
(2, 'Hiring BDE - Current Account | Hyderabad', 'SBICAP Securities Limited', 'Bangalore', 'Ensure quality new acquisition on CA accounts through bank leads, referrals and cold calls in the catchment area.\r\nEnsure quality customer service is delivered.\r\n\r\nMeet productivity norms defined through support of channels and own efforts.\r\n\r\n', '<ul class=\'bullets\'><li>Owning, tracking, and resolving database related incidents and requests.</li><li>Assisting developers in optimizing SQL code and stored procedures to ensure optimal SQL Server performance. Develop SSIS Packages and SSRS Reports.</li><li>Reviewing service-related reports (database backups, maintenance, monitoring) on a daily basis to ensure service-related issues are identified and resolved within established SLAs.</li><li>Responding to database related alerts and escalations and working with database engineering to come up with strategic solutions to recurring problems.</li><li>Initiating and performing changes on production systems and proactively escalating any issues that cannot be resolved within the established timeframes.</li></ul>', '<ul class=\'bullets\'><li>Associate degree plus 3 years of experience providing end-user technical support preferred; 3+ years working with Microsoft SQL Server.</li><li>Experience or training in Performance Tuning, Query Optimization, using Performance Monitor, SQL Profiler and other related monitoring and troubleshooting tools such as Sentry One;</li><li>Ability to detect and troubleshoot SQL Server related CPU,memory,I/O, disk space and other resource contention;</li><li>Working knowledge of backups, restores, recovery models, database shrink operations, DBCC commands;</li><li>Working knowledge of indexes, index management, integrity checks, configuration, patching;</li><li>Knowledge of SQL Server tools ( Profiler, DTA, SSMS, SAC, SSCM, PerfMon, DMVs, system sprocs);</li><li>SQL Development – ability to write and troubleshoot SQL Code and design ( stored procs, functions, tables, views, triggers, indexes, constraints). Ability to write SSIS packages and convert queries in SSRS Reports;</li><li>Ability to work with Infrastructure and Virtualization staff on the performance of Hardware and Virtual component across CPU, Memory and backend Storage environments to provide optimum Hardware and Operating Systems selection;</li><li>Solid acquaintance with windows server, security delegation, SPNs, storage components;</li><li>SQL Database Operational support to technical users;</li></ul>', '<ul class=\'bullets\'><li>Saturdays and Sundays Off.</li><li>We provide working environment including full desktop.</li></ul>', 35000, 50000, 'sathish@gmail.com', 'Full time', '2021-07-22', 2, 'no', '2021-06-30', '2021-07-18 19:15:37', 'B.E./B.Tech/MCA with specialization in Computers/Electronics/IT OR M.Sc in Computer Science/IT'),
(3, 'SQL Database ', ' Tata Consultancy Service', 'India', 'Purpose: The SQL Server Database Administrator role is responsible for providing operational database services to the organization.', '<ul class=\'bullets\'><li>Owning, tracking, and resolving database related incidents and requests.</li><li>Assisting developers in optimizing SQL code and stored procedures to ensure optimal SQL Server performance. Develop SSIS Packages and SSRS Reports.</li><li>Reviewing service-related reports (database backups, maintenance, monitoring) on a daily basis to ensure service-related issues are identified and resolved within established SLAs.</li><li>Responding to database related alerts and escalations and working with database engineering to come up with strategic solutions to recurring problems.</li><li>Initiating and performing changes on production systems and proactively escalating any issues that cannot be resolved within the established timeframes.</li></ul>', '<ul class=\'bullets\'><li>Associate degree plus 3 years of experience providing end-user technical support preferred; 3+ years working with Microsoft SQL Server.</li><li>Experience or training in Performance Tuning, Query Optimization, using Performance Monitor, SQL Profiler and other related monitoring and troubleshooting tools such as Sentry One;</li><li>Ability to detect and troubleshoot SQL Server related CPU,memory,I/O, disk space and other resource contention;</li><li>Working knowledge of backups, restores, recovery models, database shrink operations, DBCC commands;</li><li>Working knowledge of indexes, index management, integrity checks, configuration, patching;</li><li>Knowledge of SQL Server tools ( Profiler, DTA, SSMS, SAC, SSCM, PerfMon, DMVs, system sprocs);</li><li>SQL Development – ability to write and troubleshoot SQL Code and design ( stored procs, functions, tables, views, triggers, indexes, constraints). Ability to write SSIS packages and convert queries in SSRS Reports;</li><li>Ability to work with Infrastructure and Virtualization staff on the performance of Hardware and Virtual component across CPU, Memory and backend Storage environments to provide optimum Hardware and Operating Systems selection;</li><li>Solid acquaintance with windows server, security delegation, SPNs, storage components;</li><li>SQL Database Operational support to technical users;</li></ul>', '<ul class=\'bullets\'><li>Saturdays and Sundays Off.</li><li>We provide working environment including full desktop.</li></ul>', 101575, 149588, 'sai22@gmail.com', 'Full time', '2021-07-04', 3, 'yes', '2021-06-30', '2021-06-27 21:08:27', 'B.E./B.Tech/MCA with specialization in Computers/Electronics/IT OR M.Sc in Computer Science/IT'),
(23, 'Database Administrator', 'Wealus technology solutions pvt ltd', 'Mumbai', 'As part of a team whose mission is to serve state government and to support safe and healthy communities throughout Oregon, you’ll close each day with a sense of purpose inherent to public service. When you become a DOJ team member, you join an agency that values loyal and enthusiastic employees by providing a competitive salary and great benefits, including excellent medical, vision, dental, pension and retirement programs. You’ll also have access to paid Sick Leave, Vacation, Personal Business Leave, and 10 paid holidays a year', '<ul class=\'bullets\'><li>Design, implement and maintain database systems to support application and business needs.</li><li>Ensure databases are properly backed up, patched, and upgraded.</li><li>Produce documentation detailing the structure and construction of data application systems including narratives, program logic, and data flow diagrams.</li><li>Conduct business analysis and research for projects involving new technologies or business processes.</li><li>Involve managers, staff, and business partners to define requirements using standard department processes.</li><li>Prepare requirements documentation, feasibility studies, and scope statements per department standards.</li><li>Perform data analysis and develop and maintain database reports to support application, business, and IS needs.</li><li>Diagnose and resolve problems and errors with data or database systems that are complex and impact business critical systems.</li><li>Coordinate with customers, other IS staff and vendors.</li><li>Understand the agency’s affirmative action goals and objectives.</li><li>Recognize the value of individual and cultural differences, create work environments where individuals’ differences are valued, and consistently treat staff, colleagues, customers and stakeholders/partners with dignity and respect.</li></ul>', '<ul class=\'bullets\'><li>Four (4) years of information systems experience that demonstrate knowledge and experience in, OR the ability to master, .NET development and programming languages and SQL Server database management (SQL Server Management Studio).</li><li>Verbal and written communication.</li><li>Communicate technical information in a way that is understandable by customers and users.</li><li>Working independently and part of a team.</li></ul>', '<ul class=\'bullets\'><li>Salary Range $4,701 - $7,109 per month with additional bonuses.</li><li>Holidays and leave hours.</li></ul>', 150000, 250000, 'sai22@gmail.com', 'Full time', '2021-07-06', 1, 'yes', '2021-06-27', '2021-07-19 11:00:07', 'B.E./B.Tech/MCA with specialization in Computers/Electronics/IT OR M.Sc in Computer Science/IT'),
(24, 'Programmer Analyst-.NET, SQL', ' Tata Consultancy Service', 'India', 'Driven by technology-enabled growth and success in business for our clients, we employ unsurpassed methodologies to establish and conquer new realms of global markets. We follow industry’s best business practices and models to deliver deadline-driven, customizable, flexible and scalable business services such as Application Development, Mobile App Development, Cloud and Branding Services.', '<ul class=\'bullets\'><li>Programming, debugging, and documenting complex software applications.</li><li>Developing and implementing web-based solutions.</li><li>Providing technical and strategic advice to Manager, Applications Development and other Broadridge Managers.</li><li>Work with the Product Management team to build project specifications.</li><li>Collaborate with the Change Management team during development to ensure quality code.</li><li>Works with manager and teammates to build accurate estimates for assigned business support and project support development tasks, delivering reliable, reusable and supportable software on time and on-budget.</li><li>Performing other duties as assigned.</li></ul>', '<ul class=\'bullets\'><li>4+ years of experience programming with C#, JavaScript, CSS, and SQL</li><li>B.S. in Computer Science / related field required</li></ul>', '<ul class=\'bullets\'><li>We provide our own working environment with desktop setups.</li></ul>', 81589, 96500, 'sai22@gmail.com', 'Full time', '2021-07-30', 3, 'no', '2021-06-30', '2021-06-27 21:16:10', 'B.E./B.Tech/MCA with specialization in Computers/Electronics/IT OR M.Sc in Computer Science/IT'),
(26, 'Team Leader | Current Account Acquisition | Hyderabad | SBI Securities ', 'SBICAP Securities Limited', 'India', 'Dear Candidate\r\nWe are hiring young & dynamic candidates for Team Leader position in our Current Account Division for SBICAP Securities Ltd.\r\nLocations : Hyderabad', 'Generate leads for his team using bank resources, individual contacts & tele-calling & branch walk-in customers.\r\nHelp provide regular training to team members on sales strategy to help convince customers to open current account.', 'The individual will be responsible for team\'s performance on sourcing of current accounts for the bank.\r\nProvide training to the BDEs. While the training on the Banks products will be Banks responsibility, training of BDEs on marketing function including guiding them on approaching, interacting and sourcing from the potential customers will be that of TL.\r\nSource high value current accounts of retailers, traders, MSME companies etc.', 'Generating leads for other products and passing the same to the branch for follow ups.\r\nEnsuring the team meets the defined monthly target along with individual targets for satisfactory performance by helping the team in calling and visiting potential customers.', 30000, 80000, 'sathish@gmail.com', 'Full time', '2021-07-30', 2, 'no', '2021-06-30', '0000-00-00 00:00:00', 'Fresher can apply if open for the role.\r\n2+ years of experience in banking sales (liability sales preferably).\r\nExperience of working with large private sector banks will be preferred.');

-- --------------------------------------------------------

--
-- Table structure for table `paid`
--

CREATE TABLE `paid` (
  `postid` int(10) NOT NULL,
  `postname` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `details` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `months` int(10) NOT NULL,
  `img` varchar(60) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paid`
--

INSERT INTO `paid` (`postid`, `postname`, `title`, `details`, `price`, `months`, `img`, `date`) VALUES
(1, 'RESUME DISPLAY', 'Increase your Profile Visibility to recruiters upto 3 times.', 'Get a Featured Profile, Stand out and get noticed in recruiter eyes.', 1949, 3, '1625331400-s1.png', '2021-07-03 20:57:41'),
(2, 'PRIORITY APPLICANT', 'Be a Priority Applicant & increase your chance of getting a call.', 'Our experts will understand your job preference & set alerts. Instant job on SMS.', 899, 3, '1625330133-s2.png', '2021-07-03 20:57:41'),
(3, 'JOB SEARCH BOOSTER', 'Get your resume reviewed and improve your job application.', 'Take help from over 20,000 seniors in top companies like TCS, HCL, Accenture etc.', 1999, 9, '1625330254s3.png', '2021-07-03 22:07:34'),
(4, 'RESUME CRITIQUE', 'Get your resume reviewed and improve your job application ', 'Our experts will analyze your resume and send a detailed report', 599, 3, '1625334800s4.png', '2021-07-03 23:23:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `applied`
--
ALTER TABLE `applied`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedbackid`);

--
-- Indexes for table `follow`
--
ALTER TABLE `follow`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `hr`
--
ALTER TABLE `hr`
  ADD PRIMARY KEY (`hrid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `paid`
--
ALTER TABLE `paid`
  ADD PRIMARY KEY (`postid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applied`
--
ALTER TABLE `applied`
  MODIFY `aid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedbackid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `follow`
--
ALTER TABLE `follow`
  MODIFY `fid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `hr`
--
ALTER TABLE `hr`
  MODIFY `hrid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `paid`
--
ALTER TABLE `paid`
  MODIFY `postid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
